<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-15 17:33:34 --> Could not find the language line "Mechanic"
ERROR - 2023-05-15 17:33:49 --> 404 Page Not Found: /index
ERROR - 2023-05-15 17:33:49 --> 404 Page Not Found: /index
ERROR - 2023-05-15 17:33:49 --> 404 Page Not Found: /index
ERROR - 2023-05-15 17:33:56 --> Could not find the language line "Mechanic"
ERROR - 2023-05-15 17:33:57 --> Could not find the language line "Mechanic"
ERROR - 2023-05-15 17:33:58 --> Could not find the language line "Mechanic"
ERROR - 2023-05-15 17:34:00 --> Could not find the language line "Mechanic"
ERROR - 2023-05-15 17:34:04 --> Could not find the language line "Mechanic"
ERROR - 2023-05-15 17:34:39 --> Could not find the language line "Mechanic"
ERROR - 2023-05-15 17:34:39 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\redlabel\view_product.php 70
ERROR - 2023-05-15 17:34:43 --> Could not find the language line "Mechanic"
ERROR - 2023-05-15 17:34:44 --> Could not find the language line "Mechanic"
ERROR - 2023-05-15 17:34:44 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\redlabel\view_product.php 70
ERROR - 2023-05-15 17:34:48 --> Could not find the language line "Mechanic"
ERROR - 2023-05-15 17:38:18 --> 404 Page Not Found: /index
ERROR - 2023-05-15 17:38:18 --> 404 Page Not Found: /index
ERROR - 2023-05-15 17:38:18 --> 404 Page Not Found: /index
ERROR - 2023-05-15 17:38:23 --> Could not find the language line "Mechanic"
ERROR - 2023-05-15 17:38:26 --> Could not find the language line "Mechanic"
ERROR - 2023-05-15 17:38:27 --> Could not find the language line "Mechanic"
ERROR - 2023-05-15 17:38:28 --> Could not find the language line "Mechanic"
ERROR - 2023-05-15 17:38:31 --> 404 Page Not Found: /index
ERROR - 2023-05-15 17:38:31 --> 404 Page Not Found: /index
ERROR - 2023-05-15 17:38:31 --> 404 Page Not Found: /index
ERROR - 2023-05-15 17:38:33 --> Could not find the language line "Mechanic"
ERROR - 2023-05-15 17:38:34 --> Could not find the language line "Mechanic"
ERROR - 2023-05-15 17:38:35 --> Could not find the language line "Mechanic"
ERROR - 2023-05-15 17:38:36 --> Could not find the language line "Mechanic"
ERROR - 2023-05-15 17:38:39 --> Could not find the language line "Mechanic"
