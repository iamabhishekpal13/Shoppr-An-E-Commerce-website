<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-10 17:12:23 --> Could not find the language line "show_menu"
ERROR - 2023-05-10 17:12:23 --> Could not find the language line "hide_menu"
ERROR - 2023-05-10 17:13:18 --> Could not find the language line "show_menu"
ERROR - 2023-05-10 17:13:18 --> Could not find the language line "hide_menu"
ERROR - 2023-05-10 17:13:20 --> Could not find the language line "show_menu"
ERROR - 2023-05-10 17:13:20 --> Could not find the language line "hide_menu"
ERROR - 2023-05-10 17:13:21 --> Could not find the language line "show_menu"
ERROR - 2023-05-10 17:13:21 --> Could not find the language line "hide_menu"
ERROR - 2023-05-10 17:13:22 --> Severity: 8192 --> Required parameter $limit follows optional parameter $lang C:\xampp\htdocs\shop\application\modules\admin\models\Blog_model.php 34
ERROR - 2023-05-10 17:13:22 --> Severity: 8192 --> Required parameter $page follows optional parameter $lang C:\xampp\htdocs\shop\application\modules\admin\models\Blog_model.php 0
ERROR - 2023-05-10 17:13:22 --> Could not find the language line "show_menu"
ERROR - 2023-05-10 17:13:22 --> Could not find the language line "hide_menu"
ERROR - 2023-05-10 17:13:24 --> Could not find the language line "show_menu"
ERROR - 2023-05-10 17:13:24 --> Could not find the language line "hide_menu"
ERROR - 2023-05-10 17:13:26 --> Could not find the language line "show_menu"
ERROR - 2023-05-10 17:13:26 --> Could not find the language line "hide_menu"
ERROR - 2023-05-10 17:13:27 --> Could not find the language line "show_menu"
ERROR - 2023-05-10 17:13:27 --> Could not find the language line "hide_menu"
ERROR - 2023-05-10 17:13:28 --> Could not find the language line "show_menu"
ERROR - 2023-05-10 17:13:28 --> Could not find the language line "hide_menu"
ERROR - 2023-05-10 17:13:29 --> Could not find the language line "show_menu"
ERROR - 2023-05-10 17:13:29 --> Could not find the language line "hide_menu"
ERROR - 2023-05-10 17:13:33 --> Could not find the language line "show_menu"
ERROR - 2023-05-10 17:13:33 --> Could not find the language line "hide_menu"
ERROR - 2023-05-10 17:13:33 --> 404 Page Not Found: /index
ERROR - 2023-05-10 17:13:33 --> 404 Page Not Found: /index
ERROR - 2023-05-10 17:13:33 --> 404 Page Not Found: /index
ERROR - 2023-05-10 17:13:33 --> 404 Page Not Found: /index
ERROR - 2023-05-10 17:13:34 --> 404 Page Not Found: /index
ERROR - 2023-05-10 17:13:34 --> 404 Page Not Found: /index
ERROR - 2023-05-10 17:13:37 --> Could not find the language line "show_menu"
ERROR - 2023-05-10 17:13:37 --> Could not find the language line "hide_menu"
ERROR - 2023-05-10 17:13:44 --> Could not find the language line "show_menu"
ERROR - 2023-05-10 17:13:44 --> Could not find the language line "hide_menu"
ERROR - 2023-05-10 17:14:05 --> Could not find the language line "show_menu"
ERROR - 2023-05-10 17:14:05 --> Could not find the language line "hide_menu"
ERROR - 2023-05-10 17:14:06 --> Could not find the language line "show_menu"
ERROR - 2023-05-10 17:14:06 --> Could not find the language line "hide_menu"
ERROR - 2023-05-10 17:14:10 --> Could not find the language line "show_menu"
ERROR - 2023-05-10 17:14:10 --> Could not find the language line "hide_menu"
ERROR - 2023-05-10 17:14:15 --> Could not find the language line "show_menu"
ERROR - 2023-05-10 17:14:15 --> Could not find the language line "hide_menu"
ERROR - 2023-05-10 17:14:18 --> Could not find the language line "show_menu"
ERROR - 2023-05-10 17:14:18 --> Could not find the language line "hide_menu"
ERROR - 2023-05-10 17:14:30 --> Severity: 8192 --> Required parameter $limit follows optional parameter $lang C:\xampp\htdocs\shop\application\modules\admin\models\Blog_model.php 34
ERROR - 2023-05-10 17:14:30 --> Severity: 8192 --> Required parameter $page follows optional parameter $lang C:\xampp\htdocs\shop\application\modules\admin\models\Blog_model.php 0
ERROR - 2023-05-10 17:14:30 --> Could not find the language line "show_menu"
ERROR - 2023-05-10 17:14:30 --> Could not find the language line "hide_menu"
ERROR - 2023-05-10 17:14:38 --> Severity: 8192 --> Required parameter $limit follows optional parameter $lang C:\xampp\htdocs\shop\application\modules\admin\models\Blog_model.php 34
ERROR - 2023-05-10 17:14:38 --> Severity: 8192 --> Required parameter $page follows optional parameter $lang C:\xampp\htdocs\shop\application\modules\admin\models\Blog_model.php 0
ERROR - 2023-05-10 17:14:38 --> Could not find the language line "show_menu"
ERROR - 2023-05-10 17:14:38 --> Could not find the language line "hide_menu"
ERROR - 2023-05-10 17:14:41 --> Could not find the language line "show_menu"
ERROR - 2023-05-10 17:14:41 --> Could not find the language line "hide_menu"
ERROR - 2023-05-10 17:14:44 --> Could not find the language line "show_menu"
ERROR - 2023-05-10 17:14:44 --> Could not find the language line "hide_menu"
ERROR - 2023-05-10 17:14:44 --> Could not find the language line "show_menu"
ERROR - 2023-05-10 17:14:44 --> Could not find the language line "hide_menu"
ERROR - 2023-05-10 17:14:59 --> Could not find the language line "show_menu"
ERROR - 2023-05-10 17:14:59 --> Could not find the language line "hide_menu"
ERROR - 2023-05-10 17:15:05 --> Could not find the language line "show_menu"
ERROR - 2023-05-10 17:15:05 --> Could not find the language line "hide_menu"
ERROR - 2023-05-10 17:15:07 --> Could not find the language line "show_menu"
ERROR - 2023-05-10 17:15:07 --> Could not find the language line "hide_menu"
ERROR - 2023-05-10 17:15:16 --> Could not find the language line "show_menu"
ERROR - 2023-05-10 17:15:16 --> Could not find the language line "hide_menu"
ERROR - 2023-05-10 17:15:17 --> Could not find the language line "show_menu"
ERROR - 2023-05-10 17:15:17 --> Could not find the language line "hide_menu"
ERROR - 2023-05-10 17:15:20 --> Could not find the language line "show_menu"
ERROR - 2023-05-10 17:15:20 --> Could not find the language line "hide_menu"
ERROR - 2023-05-10 17:15:21 --> Could not find the language line "show_menu"
ERROR - 2023-05-10 17:15:21 --> Could not find the language line "hide_menu"
ERROR - 2023-05-10 17:15:38 --> 404 Page Not Found: ../modules/vendor/controllers//index
ERROR - 2023-05-10 17:15:59 --> 404 Page Not Found: ../modules/vendor/controllers//index
ERROR - 2023-05-10 17:16:10 --> Could not find the language line "show_menu"
ERROR - 2023-05-10 17:16:10 --> Could not find the language line "hide_menu"
ERROR - 2023-05-10 17:16:27 --> Could not find the language line "show_menu"
ERROR - 2023-05-10 17:16:27 --> Could not find the language line "hide_menu"
ERROR - 2023-05-10 17:16:35 --> Could not find the language line "show_menu"
ERROR - 2023-05-10 17:16:35 --> Could not find the language line "hide_menu"
ERROR - 2023-05-10 17:16:36 --> Could not find the language line "show_menu"
ERROR - 2023-05-10 17:16:36 --> Could not find the language line "hide_menu"
ERROR - 2023-05-10 17:16:40 --> Could not find the language line "show_menu"
ERROR - 2023-05-10 17:16:40 --> Could not find the language line "hide_menu"
ERROR - 2023-05-10 17:18:30 --> Could not find the language line "show_menu"
ERROR - 2023-05-10 17:18:30 --> Could not find the language line "hide_menu"
ERROR - 2023-05-10 17:19:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-10 17:19:22 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-10 17:19:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-10 17:23:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-10 17:23:09 --> Severity: 8192 --> Required parameter $limit follows optional parameter $lang C:\xampp\htdocs\shop\application\modules\admin\models\Blog_model.php 34
ERROR - 2023-05-10 17:23:09 --> Severity: 8192 --> Required parameter $page follows optional parameter $lang C:\xampp\htdocs\shop\application\modules\admin\models\Blog_model.php 0
ERROR - 2023-05-10 17:39:36 --> Severity: 8192 --> Required parameter $limit follows optional parameter $lang C:\xampp\htdocs\shop\application\modules\admin\models\Blog_model.php 34
ERROR - 2023-05-10 17:39:36 --> Severity: 8192 --> Required parameter $page follows optional parameter $lang C:\xampp\htdocs\shop\application\modules\admin\models\Blog_model.php 0
ERROR - 2023-05-10 17:39:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-10 17:41:40 --> Could not find the language line "show_menu"
ERROR - 2023-05-10 17:41:40 --> Could not find the language line "hide_menu"
ERROR - 2023-05-10 17:46:24 --> Could not find the language line "show_menu"
ERROR - 2023-05-10 17:46:24 --> Could not find the language line "hide_menu"
ERROR - 2023-05-10 17:47:39 --> Severity: 8192 --> Required parameter $limit follows optional parameter $lang C:\xampp\htdocs\shop\application\modules\admin\models\Blog_model.php 34
ERROR - 2023-05-10 17:47:39 --> Severity: 8192 --> Required parameter $page follows optional parameter $lang C:\xampp\htdocs\shop\application\modules\admin\models\Blog_model.php 0
ERROR - 2023-05-10 17:47:49 --> Severity: 8192 --> Required parameter $limit follows optional parameter $lang C:\xampp\htdocs\shop\application\modules\admin\models\Blog_model.php 34
ERROR - 2023-05-10 17:47:49 --> Severity: 8192 --> Required parameter $page follows optional parameter $lang C:\xampp\htdocs\shop\application\modules\admin\models\Blog_model.php 0
ERROR - 2023-05-10 17:49:19 --> Could not find the language line "show_menu"
ERROR - 2023-05-10 17:49:19 --> Could not find the language line "hide_menu"
ERROR - 2023-05-10 17:50:03 --> Could not find the language line "show_menu"
ERROR - 2023-05-10 17:50:03 --> Could not find the language line "hide_menu"
ERROR - 2023-05-10 17:50:04 --> Could not find the language line "show_menu"
ERROR - 2023-05-10 17:50:04 --> Could not find the language line "hide_menu"
ERROR - 2023-05-10 17:50:05 --> Could not find the language line "show_menu"
ERROR - 2023-05-10 17:50:05 --> Could not find the language line "hide_menu"
ERROR - 2023-05-10 17:50:16 --> Could not find the language line "show_menu"
ERROR - 2023-05-10 17:50:16 --> Could not find the language line "hide_menu"
ERROR - 2023-05-10 17:50:24 --> Could not find the language line "show_menu"
ERROR - 2023-05-10 17:50:24 --> Could not find the language line "hide_menu"
ERROR - 2023-05-10 17:51:49 --> Could not find the language line "show_menu"
ERROR - 2023-05-10 17:51:49 --> Could not find the language line "hide_menu"
ERROR - 2023-05-10 17:53:03 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\redlabel\view_product.php 70
ERROR - 2023-05-10 17:53:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-10 17:53:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-10 17:53:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\redlabel\checkout.php 46
