<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-20 10:53:32 --> 404 Page Not Found: /index
ERROR - 2023-05-20 10:53:32 --> 404 Page Not Found: /index
ERROR - 2023-05-20 10:53:43 --> 404 Page Not Found: /index
ERROR - 2023-05-20 10:53:43 --> 404 Page Not Found: /index
ERROR - 2023-05-20 10:55:49 --> 404 Page Not Found: /index
ERROR - 2023-05-20 10:56:10 --> 404 Page Not Found: /index
ERROR - 2023-05-20 10:56:10 --> 404 Page Not Found: /index
ERROR - 2023-05-20 10:56:10 --> 404 Page Not Found: /index
ERROR - 2023-05-20 10:56:52 --> Could not find the language line "show_menu"
ERROR - 2023-05-20 10:56:52 --> Could not find the language line "hide_menu"
ERROR - 2023-05-20 10:56:55 --> Could not find the language line "show_menu"
ERROR - 2023-05-20 10:56:55 --> Could not find the language line "hide_menu"
ERROR - 2023-05-20 10:57:36 --> Could not find the language line "show_menu"
ERROR - 2023-05-20 10:57:36 --> Could not find the language line "hide_menu"
ERROR - 2023-05-20 10:57:42 --> 404 Page Not Found: /index
ERROR - 2023-05-20 10:57:42 --> 404 Page Not Found: /index
ERROR - 2023-05-20 10:58:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-20 10:58:34 --> 404 Page Not Found: /index
ERROR - 2023-05-20 10:58:34 --> 404 Page Not Found: /index
ERROR - 2023-05-20 10:59:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-20 10:59:22 --> 404 Page Not Found: /index
ERROR - 2023-05-20 10:59:22 --> 404 Page Not Found: /index
ERROR - 2023-05-20 10:59:35 --> 404 Page Not Found: /index
ERROR - 2023-05-20 10:59:35 --> 404 Page Not Found: /index
ERROR - 2023-05-20 10:59:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-20 10:59:38 --> 404 Page Not Found: /index
ERROR - 2023-05-20 10:59:38 --> 404 Page Not Found: /index
ERROR - 2023-05-20 10:59:43 --> 404 Page Not Found: /index
ERROR - 2023-05-20 10:59:43 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:00:07 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:00:07 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:00:25 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:00:25 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:01:19 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:01:19 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:01:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-20 11:01:55 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-20 11:01:57 --> Could not find the language line "user_order_history"
ERROR - 2023-05-20 11:02:06 --> Could not find the language line "user_order_history"
ERROR - 2023-05-20 11:02:08 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:02:08 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:02:17 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:02:17 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:02:22 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-20 11:02:27 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:02:27 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:02:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-20 11:02:33 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:02:33 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:02:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-20 11:03:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-20 11:03:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-20 11:03:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-20 11:03:43 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-20 11:03:55 --> Could not find the language line "show_menu"
ERROR - 2023-05-20 11:03:55 --> Could not find the language line "hide_menu"
ERROR - 2023-05-20 11:03:57 --> Could not find the language line "show_menu"
ERROR - 2023-05-20 11:03:57 --> Could not find the language line "hide_menu"
ERROR - 2023-05-20 11:03:57 --> Could not find the language line "show_menu"
ERROR - 2023-05-20 11:03:57 --> Could not find the language line "hide_menu"
ERROR - 2023-05-20 11:04:55 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:04:55 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:05:10 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:05:11 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:05:24 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:05:24 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:06:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-20 11:07:01 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:07:01 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:07:21 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:07:21 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:08:38 --> Could not find the language line "show_menu"
ERROR - 2023-05-20 11:08:38 --> Could not find the language line "hide_menu"
ERROR - 2023-05-20 11:09:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-20 11:19:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-20 11:19:29 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:19:29 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:19:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-20 11:19:38 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:19:38 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:19:57 --> Could not find the language line "show_menu"
ERROR - 2023-05-20 11:19:57 --> Could not find the language line "hide_menu"
ERROR - 2023-05-20 11:20:09 --> Could not find the language line "show_menu"
ERROR - 2023-05-20 11:20:09 --> Could not find the language line "hide_menu"
ERROR - 2023-05-20 11:21:00 --> Could not find the language line "show_menu"
ERROR - 2023-05-20 11:21:00 --> Could not find the language line "hide_menu"
ERROR - 2023-05-20 11:21:24 --> Could not find the language line "show_menu"
ERROR - 2023-05-20 11:21:24 --> Could not find the language line "hide_menu"
ERROR - 2023-05-20 11:22:35 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:22:35 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:27:20 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:27:20 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:27:25 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:27:26 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:27:37 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:27:37 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:28:11 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:28:11 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:28:14 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:28:14 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:28:21 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:28:21 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:29:07 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:29:07 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:29:42 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:29:42 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:29:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-20 11:29:46 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:29:46 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:34:33 --> Could not find the language line "show_menu"
ERROR - 2023-05-20 11:34:33 --> Could not find the language line "hide_menu"
ERROR - 2023-05-20 11:34:40 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:34:40 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:34:44 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:34:44 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:35:57 --> Could not find the language line "show_menu"
ERROR - 2023-05-20 11:35:57 --> Could not find the language line "hide_menu"
ERROR - 2023-05-20 11:36:00 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:36:00 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:36:18 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:37:17 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:37:27 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:37:27 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:37:33 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:38:40 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:38:40 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:38:42 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:38:42 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:38:42 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:38:45 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:38:45 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:38:49 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:39:39 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:39:39 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:39:39 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:39:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-20 11:39:53 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:39:53 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:41:23 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:41:23 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:41:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-20 11:42:00 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:42:00 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:42:26 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:42:26 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:43:39 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\shop\system\libraries\Email.php 1903
ERROR - 2023-05-20 11:44:12 --> Could not find the language line "show_menu"
ERROR - 2023-05-20 11:44:12 --> Could not find the language line "hide_menu"
ERROR - 2023-05-20 11:44:16 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:44:16 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:44:18 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:44:18 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:44:57 --> Could not find the language line "show_menu"
ERROR - 2023-05-20 11:44:57 --> Could not find the language line "hide_menu"
ERROR - 2023-05-20 11:45:09 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\shop\system\libraries\Email.php 1903
ERROR - 2023-05-20 11:45:32 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\shop\system\libraries\Email.php 1903
ERROR - 2023-05-20 11:46:25 --> 404 Page Not Found: /index
ERROR - 2023-05-20 11:46:25 --> 404 Page Not Found: /index
ERROR - 2023-05-20 17:13:23 --> 404 Page Not Found: /index
ERROR - 2023-05-20 17:13:23 --> 404 Page Not Found: /index
ERROR - 2023-05-20 17:13:38 --> 404 Page Not Found: /index
ERROR - 2023-05-20 17:13:38 --> 404 Page Not Found: /index
ERROR - 2023-05-20 17:13:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-20 17:13:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-20 17:14:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-20 17:14:12 --> Could not find the language line "user_order_history"
ERROR - 2023-05-20 17:14:43 --> Could not find the language line "show_menu"
ERROR - 2023-05-20 17:14:43 --> Could not find the language line "hide_menu"
ERROR - 2023-05-20 17:14:47 --> Could not find the language line "show_menu"
ERROR - 2023-05-20 17:14:47 --> Could not find the language line "hide_menu"
ERROR - 2023-05-20 17:15:50 --> Could not find the language line "show_menu"
ERROR - 2023-05-20 17:15:50 --> Could not find the language line "hide_menu"
ERROR - 2023-05-20 17:16:23 --> Could not find the language line "show_menu"
ERROR - 2023-05-20 17:16:23 --> Could not find the language line "hide_menu"
ERROR - 2023-05-20 17:16:36 --> 404 Page Not Found: /index
ERROR - 2023-05-20 17:16:36 --> 404 Page Not Found: /index
ERROR - 2023-05-20 17:16:37 --> 404 Page Not Found: /index
ERROR - 2023-05-20 17:16:37 --> 404 Page Not Found: /index
ERROR - 2023-05-20 17:16:50 --> Could not find the language line "show_menu"
ERROR - 2023-05-20 17:16:50 --> Could not find the language line "hide_menu"
ERROR - 2023-05-20 17:16:56 --> 404 Page Not Found: /index
ERROR - 2023-05-20 17:16:56 --> 404 Page Not Found: /index
ERROR - 2023-05-20 17:16:57 --> 404 Page Not Found: /index
ERROR - 2023-05-20 17:16:57 --> 404 Page Not Found: /index
ERROR - 2023-05-20 17:17:12 --> Could not find the language line "show_menu"
ERROR - 2023-05-20 17:17:12 --> Could not find the language line "hide_menu"
ERROR - 2023-05-20 17:17:22 --> Could not find the language line "show_menu"
ERROR - 2023-05-20 17:17:22 --> Could not find the language line "hide_menu"
ERROR - 2023-05-20 17:17:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-20 17:17:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-20 17:17:56 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-20 17:18:01 --> Could not find the language line "user_order_history"
ERROR - 2023-05-20 17:18:35 --> Could not find the language line "show_menu"
ERROR - 2023-05-20 17:18:35 --> Could not find the language line "hide_menu"
ERROR - 2023-05-20 17:19:08 --> Could not find the language line "show_menu"
ERROR - 2023-05-20 17:19:08 --> Could not find the language line "hide_menu"
ERROR - 2023-05-20 17:19:30 --> 404 Page Not Found: /index
ERROR - 2023-05-20 17:19:30 --> 404 Page Not Found: /index
ERROR - 2023-05-20 17:19:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-20 17:19:40 --> 404 Page Not Found: /index
ERROR - 2023-05-20 17:19:40 --> 404 Page Not Found: /index
ERROR - 2023-05-20 17:19:55 --> 404 Page Not Found: /index
ERROR - 2023-05-20 17:19:55 --> 404 Page Not Found: /index
ERROR - 2023-05-20 17:31:26 --> Could not find the language line "user_order_history"
ERROR - 2023-05-20 17:31:32 --> 404 Page Not Found: /index
ERROR - 2023-05-20 17:31:32 --> 404 Page Not Found: /index
