<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-08 17:55:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-08 17:56:00 --> 404 Page Not Found: /index
ERROR - 2023-05-08 17:56:00 --> 404 Page Not Found: /index
ERROR - 2023-05-08 17:56:00 --> 404 Page Not Found: /index
ERROR - 2023-05-08 17:59:20 --> Could not find the language line "show_menu"
ERROR - 2023-05-08 17:59:20 --> Could not find the language line "hide_menu"
ERROR - 2023-05-08 17:59:28 --> Could not find the language line "show_menu"
ERROR - 2023-05-08 17:59:28 --> Could not find the language line "hide_menu"
ERROR - 2023-05-08 17:59:46 --> Could not find the language line "show_menu"
ERROR - 2023-05-08 17:59:46 --> Could not find the language line "hide_menu"
ERROR - 2023-05-08 18:04:38 --> Could not find the language line "show_menu"
ERROR - 2023-05-08 18:04:38 --> Could not find the language line "hide_menu"
ERROR - 2023-05-08 18:05:06 --> Could not find the language line "show_menu"
ERROR - 2023-05-08 18:05:06 --> Could not find the language line "hide_menu"
ERROR - 2023-05-08 18:05:14 --> 404 Page Not Found: /index
ERROR - 2023-05-08 18:05:14 --> 404 Page Not Found: /index
ERROR - 2023-05-08 18:05:14 --> 404 Page Not Found: /index
ERROR - 2023-05-08 18:06:05 --> 404 Page Not Found: /index
ERROR - 2023-05-08 18:06:05 --> 404 Page Not Found: /index
ERROR - 2023-05-08 18:06:05 --> 404 Page Not Found: /index
ERROR - 2023-05-08 18:11:53 --> 404 Page Not Found: /index
ERROR - 2023-05-08 18:11:53 --> 404 Page Not Found: /index
ERROR - 2023-05-08 18:11:53 --> 404 Page Not Found: /index
ERROR - 2023-05-08 18:15:25 --> 404 Page Not Found: /index
ERROR - 2023-05-08 18:15:25 --> 404 Page Not Found: /index
ERROR - 2023-05-08 18:15:25 --> 404 Page Not Found: /index
ERROR - 2023-05-08 18:16:01 --> 404 Page Not Found: /index
ERROR - 2023-05-08 18:16:01 --> 404 Page Not Found: /index
ERROR - 2023-05-08 18:16:01 --> 404 Page Not Found: /index
ERROR - 2023-05-08 18:16:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-08 18:17:15 --> 404 Page Not Found: ../modules/vendor/controllers//index
ERROR - 2023-05-08 18:19:21 --> Could not find the language line "vendor_home_page"
ERROR - 2023-05-08 18:19:50 --> Severity: 8192 --> Required parameter $limit follows optional parameter $lang C:\xampp\htdocs\shop\application\modules\admin\models\Blog_model.php 34
ERROR - 2023-05-08 18:19:50 --> Severity: 8192 --> Required parameter $page follows optional parameter $lang C:\xampp\htdocs\shop\application\modules\admin\models\Blog_model.php 0
ERROR - 2023-05-08 18:19:56 --> Severity: 8192 --> Required parameter $limit follows optional parameter $lang C:\xampp\htdocs\shop\application\modules\admin\models\Blog_model.php 34
ERROR - 2023-05-08 18:19:56 --> Severity: 8192 --> Required parameter $page follows optional parameter $lang C:\xampp\htdocs\shop\application\modules\admin\models\Blog_model.php 0
ERROR - 2023-05-08 18:20:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-08 18:20:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-08 18:23:20 --> 404 Page Not Found: /index
ERROR - 2023-05-08 18:23:20 --> 404 Page Not Found: /index
ERROR - 2023-05-08 18:23:21 --> 404 Page Not Found: /index
ERROR - 2023-05-08 18:29:06 --> Could not find the language line "show_menu"
ERROR - 2023-05-08 18:29:06 --> Could not find the language line "hide_menu"
ERROR - 2023-05-08 18:29:06 --> Could not find the language line "show_menu"
ERROR - 2023-05-08 18:29:06 --> Could not find the language line "hide_menu"
ERROR - 2023-05-08 18:29:27 --> Could not find the language line "show_menu"
ERROR - 2023-05-08 18:29:27 --> Could not find the language line "hide_menu"
ERROR - 2023-05-08 18:34:06 --> 404 Page Not Found: /index
ERROR - 2023-05-08 18:34:06 --> 404 Page Not Found: /index
ERROR - 2023-05-08 18:34:07 --> 404 Page Not Found: /index
ERROR - 2023-05-08 18:37:20 --> 404 Page Not Found: /index
ERROR - 2023-05-08 18:37:20 --> 404 Page Not Found: /index
ERROR - 2023-05-08 18:37:20 --> 404 Page Not Found: /index
ERROR - 2023-05-08 18:40:06 --> 404 Page Not Found: /index
ERROR - 2023-05-08 18:40:07 --> 404 Page Not Found: /index
ERROR - 2023-05-08 18:40:07 --> 404 Page Not Found: /index
ERROR - 2023-05-08 18:41:45 --> 404 Page Not Found: /index
ERROR - 2023-05-08 18:41:45 --> 404 Page Not Found: /index
ERROR - 2023-05-08 18:41:45 --> 404 Page Not Found: /index
ERROR - 2023-05-08 18:42:31 --> 404 Page Not Found: /index
ERROR - 2023-05-08 18:42:31 --> 404 Page Not Found: /index
ERROR - 2023-05-08 18:42:31 --> 404 Page Not Found: /index
