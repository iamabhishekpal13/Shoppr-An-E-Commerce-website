<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-14 13:42:42 --> Severity: 8192 --> Required parameter $limit follows optional parameter $lang C:\xampp\htdocs\shop\application\modules\admin\models\Blog_model.php 34
ERROR - 2023-05-14 13:42:42 --> Severity: 8192 --> Required parameter $page follows optional parameter $lang C:\xampp\htdocs\shop\application\modules\admin\models\Blog_model.php 0
ERROR - 2023-05-14 13:59:19 --> Severity: 8192 --> Required parameter $limit follows optional parameter $lang C:\xampp\htdocs\shop\application\modules\admin\models\Blog_model.php 34
ERROR - 2023-05-14 13:59:19 --> Severity: 8192 --> Required parameter $page follows optional parameter $lang C:\xampp\htdocs\shop\application\modules\admin\models\Blog_model.php 0
ERROR - 2023-05-14 14:01:47 --> Severity: 8192 --> Required parameter $limit follows optional parameter $lang C:\xampp\htdocs\shop\application\modules\admin\models\Blog_model.php 34
ERROR - 2023-05-14 14:01:47 --> Severity: 8192 --> Required parameter $page follows optional parameter $lang C:\xampp\htdocs\shop\application\modules\admin\models\Blog_model.php 0
ERROR - 2023-05-14 14:04:29 --> Severity: 8192 --> Required parameter $limit follows optional parameter $lang C:\xampp\htdocs\shop\application\modules\admin\models\Blog_model.php 34
ERROR - 2023-05-14 14:04:29 --> Severity: 8192 --> Required parameter $page follows optional parameter $lang C:\xampp\htdocs\shop\application\modules\admin\models\Blog_model.php 0
ERROR - 2023-05-14 14:11:46 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:11:46 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:11:46 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:14:32 --> Could not find the language line "show_menu"
ERROR - 2023-05-14 14:14:32 --> Could not find the language line "hide_menu"
ERROR - 2023-05-14 14:14:40 --> Could not find the language line "show_menu"
ERROR - 2023-05-14 14:14:40 --> Could not find the language line "hide_menu"
ERROR - 2023-05-14 14:15:09 --> Could not find the language line "show_menu"
ERROR - 2023-05-14 14:15:09 --> Could not find the language line "hide_menu"
ERROR - 2023-05-14 14:15:42 --> 404 Page Not Found: 
ERROR - 2023-05-14 14:15:47 --> 404 Page Not Found: 
ERROR - 2023-05-14 14:15:56 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:15:56 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:15:57 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:16:26 --> Could not find the language line "show_menu"
ERROR - 2023-05-14 14:16:26 --> Could not find the language line "hide_menu"
ERROR - 2023-05-14 14:16:33 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:16:34 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:16:34 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:19:27 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:19:28 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:19:28 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:21:25 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:21:25 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:24:49 --> Could not find the language line "show_menu"
ERROR - 2023-05-14 14:24:49 --> Could not find the language line "hide_menu"
ERROR - 2023-05-14 14:24:54 --> Could not find the language line "mechanic"
ERROR - 2023-05-14 14:24:55 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:24:55 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:24:55 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:24:59 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:25:02 --> Could not find the language line "mechanic"
ERROR - 2023-05-14 14:25:03 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:25:03 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:25:03 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:29:20 --> Could not find the language line "Mechanic"
ERROR - 2023-05-14 14:29:20 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:29:20 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:29:21 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:29:21 --> Severity: 8192 --> Required parameter $limit follows optional parameter $lang C:\xampp\htdocs\shop\application\modules\admin\models\Blog_model.php 34
ERROR - 2023-05-14 14:29:21 --> Severity: 8192 --> Required parameter $page follows optional parameter $lang C:\xampp\htdocs\shop\application\modules\admin\models\Blog_model.php 0
ERROR - 2023-05-14 14:29:23 --> Severity: 8192 --> Required parameter $limit follows optional parameter $lang C:\xampp\htdocs\shop\application\modules\admin\models\Blog_model.php 34
ERROR - 2023-05-14 14:29:23 --> Severity: 8192 --> Required parameter $page follows optional parameter $lang C:\xampp\htdocs\shop\application\modules\admin\models\Blog_model.php 0
ERROR - 2023-05-14 14:33:36 --> Could not find the language line "Mechanic"
ERROR - 2023-05-14 14:33:37 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:33:37 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:33:37 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:33:39 --> Severity: 8192 --> Required parameter $limit follows optional parameter $lang C:\xampp\htdocs\shop\application\modules\admin\models\Blog_model.php 34
ERROR - 2023-05-14 14:33:39 --> Severity: 8192 --> Required parameter $page follows optional parameter $lang C:\xampp\htdocs\shop\application\modules\admin\models\Blog_model.php 0
ERROR - 2023-05-14 14:33:39 --> Could not find the language line "Mechanic"
ERROR - 2023-05-14 14:33:39 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:33:39 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:33:39 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:33:48 --> Could not find the language line "Mechanic"
ERROR - 2023-05-14 14:33:48 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:33:48 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:33:49 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:33:50 --> Could not find the language line "Mechanic"
ERROR - 2023-05-14 14:33:51 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:33:51 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:33:51 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:39:00 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:39:00 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:39:00 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:39:00 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:39:01 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:39:01 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:39:01 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:39:01 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:39:01 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:39:01 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:39:01 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:43:33 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:43:33 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:43:33 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:43:33 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:43:40 --> Could not find the language line "Mechanic"
ERROR - 2023-05-14 14:43:40 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:43:40 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:43:41 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:43:42 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:43:42 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:43:42 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:43:42 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:43:46 --> Could not find the language line "Mechanic"
ERROR - 2023-05-14 14:43:46 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:43:46 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:43:46 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:43:58 --> Could not find the language line "Mechanic"
ERROR - 2023-05-14 14:43:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-14 14:44:02 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:44:02 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:44:02 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:44:02 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:52:10 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:52:10 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:52:10 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:52:12 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:52:12 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:52:12 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:52:15 --> Could not find the language line "Mechanic"
ERROR - 2023-05-14 14:52:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-14 14:52:18 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:52:18 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:52:18 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:52:19 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:52:19 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:52:19 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:53:08 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:53:08 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:53:08 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:55:06 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:55:06 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:55:06 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:56:18 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:56:19 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:56:19 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:56:24 --> Could not find the language line "Mechanic"
ERROR - 2023-05-14 14:56:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-14 14:56:24 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:56:24 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:56:25 --> 404 Page Not Found: /index
ERROR - 2023-05-14 14:56:37 --> Could not find the language line "Mechanic"
ERROR - 2023-05-14 14:56:39 --> Could not find the language line "Mechanic"
ERROR - 2023-05-14 14:56:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-14 14:56:44 --> Could not find the language line "Mechanic"
ERROR - 2023-05-14 14:58:22 --> Could not find the language line "show_menu"
ERROR - 2023-05-14 14:58:22 --> Could not find the language line "hide_menu"
ERROR - 2023-05-14 15:01:37 --> Could not find the language line "Mechanic"
ERROR - 2023-05-14 15:01:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-14 15:01:42 --> Could not find the language line "Mechanic"
ERROR - 2023-05-14 15:02:09 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:02:09 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:02:09 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:10:29 --> Could not find the language line "Mechanic"
ERROR - 2023-05-14 15:10:29 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:10:30 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:10:30 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:10:59 --> Could not find the language line "Mechanic"
ERROR - 2023-05-14 15:10:59 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:10:59 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:10:59 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:12:45 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:12:45 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:12:45 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:17:30 --> Could not find the language line "Mechanic"
ERROR - 2023-05-14 15:17:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-14 15:17:30 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:17:30 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:17:30 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:17:40 --> Could not find the language line "Mechanic"
ERROR - 2023-05-14 15:17:40 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:17:40 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:17:40 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:17:45 --> Could not find the language line "Mechanic"
ERROR - 2023-05-14 15:17:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-14 15:17:46 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:17:46 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:17:46 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:17:51 --> Could not find the language line "Mechanic"
ERROR - 2023-05-14 15:17:51 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:17:51 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:17:51 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:17:57 --> Could not find the language line "Mechanic"
ERROR - 2023-05-14 15:17:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-14 15:17:58 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:17:58 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:17:58 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:18:04 --> Could not find the language line "Mechanic"
ERROR - 2023-05-14 15:18:04 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:18:04 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:18:04 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:18:05 --> Could not find the language line "Mechanic"
ERROR - 2023-05-14 15:18:05 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:18:05 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:18:05 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:18:06 --> Could not find the language line "Mechanic"
ERROR - 2023-05-14 15:18:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-14 15:18:06 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:18:06 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:18:06 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:18:14 --> Could not find the language line "Mechanic"
ERROR - 2023-05-14 15:18:14 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:18:14 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:18:14 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:18:16 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:18:16 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:18:16 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:18:20 --> Could not find the language line "Mechanic"
ERROR - 2023-05-14 15:18:20 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:18:20 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:18:20 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:18:21 --> Could not find the language line "Mechanic"
ERROR - 2023-05-14 15:18:21 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-14 15:18:22 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:18:22 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:18:22 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:18:27 --> Could not find the language line "Mechanic"
ERROR - 2023-05-14 15:18:27 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:18:27 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:18:28 --> 404 Page Not Found: /index
ERROR - 2023-05-14 15:31:31 --> Could not find the language line "Mechanic"
ERROR - 2023-05-14 15:31:34 --> Could not find the language line "Mechanic"
ERROR - 2023-05-14 15:31:37 --> Could not find the language line "Mechanic"
ERROR - 2023-05-14 15:31:38 --> Could not find the language line "Mechanic"
ERROR - 2023-05-14 15:31:41 --> Could not find the language line "Mechanic"
ERROR - 2023-05-14 15:31:42 --> Could not find the language line "Mechanic"
ERROR - 2023-05-14 15:31:44 --> Could not find the language line "Mechanic"
