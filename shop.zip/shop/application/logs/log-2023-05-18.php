<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-18 11:36:41 --> Could not find the language line "Mechanic"
ERROR - 2023-05-18 11:37:08 --> Could not find the language line "Mechanic"
ERROR - 2023-05-18 11:37:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-18 11:37:48 --> Could not find the language line "Mechanic"
ERROR - 2023-05-18 11:37:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-18 11:38:00 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-18 11:38:01 --> Could not find the language line "Mechanic"
ERROR - 2023-05-18 11:38:16 --> Could not find the language line "Mechanic"
ERROR - 2023-05-18 11:38:23 --> Could not find the language line "Mechanic"
ERROR - 2023-05-18 11:38:24 --> Could not find the language line "Mechanic"
ERROR - 2023-05-18 11:38:29 --> Could not find the language line "Mechanic"
ERROR - 2023-05-18 11:38:32 --> Could not find the language line "Mechanic"
ERROR - 2023-05-18 11:38:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-18 11:40:16 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 11:40:16 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 11:40:39 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 11:40:39 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 11:40:49 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 11:40:49 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 11:41:08 --> Could not find the language line "Mechanic"
ERROR - 2023-05-18 11:41:10 --> Could not find the language line "Mechanic"
ERROR - 2023-05-18 11:41:14 --> Could not find the language line "Mechanic"
ERROR - 2023-05-18 11:41:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-18 11:41:18 --> Could not find the language line "Mechanic"
ERROR - 2023-05-18 11:41:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-18 11:41:19 --> Could not find the language line "Mechanic"
ERROR - 2023-05-18 11:41:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-18 11:41:20 --> Could not find the language line "Mechanic"
ERROR - 2023-05-18 11:41:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-18 11:41:20 --> Could not find the language line "Mechanic"
ERROR - 2023-05-18 11:41:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-18 11:41:21 --> Could not find the language line "Mechanic"
ERROR - 2023-05-18 11:41:21 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-18 11:41:23 --> Could not find the language line "Mechanic"
ERROR - 2023-05-18 11:41:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-18 11:41:24 --> Could not find the language line "Mechanic"
ERROR - 2023-05-18 11:41:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-18 11:41:24 --> Could not find the language line "Mechanic"
ERROR - 2023-05-18 11:41:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-18 11:41:34 --> Could not find the language line "Mechanic"
ERROR - 2023-05-18 11:41:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-18 11:41:35 --> Could not find the language line "Mechanic"
ERROR - 2023-05-18 11:41:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-18 11:41:36 --> Could not find the language line "Mechanic"
ERROR - 2023-05-18 11:41:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-18 11:41:37 --> Could not find the language line "Mechanic"
ERROR - 2023-05-18 11:41:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-18 11:41:39 --> Could not find the language line "Mechanic"
ERROR - 2023-05-18 11:41:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-18 11:41:50 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-18 11:41:51 --> Could not find the language line "Mechanic"
ERROR - 2023-05-18 11:41:57 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 11:41:57 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 11:43:24 --> Could not find the language line "Mechanic"
ERROR - 2023-05-18 11:43:26 --> Could not find the language line "Mechanic"
ERROR - 2023-05-18 11:44:43 --> Could not find the language line "Mechanic"
ERROR - 2023-05-18 11:46:19 --> Could not find the language line "Mechanic"
ERROR - 2023-05-18 11:51:47 --> Could not find the language line "Mechanic"
ERROR - 2023-05-18 11:56:48 --> 404 Page Not Found: ../modules/vendor/controllers//index
ERROR - 2023-05-18 11:58:04 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 11:58:04 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 11:58:05 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 11:58:05 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 11:58:06 --> Could not find the language line "Mechanic"
ERROR - 2023-05-18 11:58:11 --> Could not find the language line "Mechanic"
ERROR - 2023-05-18 11:58:13 --> Could not find the language line "Mechanic"
ERROR - 2023-05-18 11:58:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-18 11:58:15 --> Could not find the language line "Mechanic"
ERROR - 2023-05-18 12:00:43 --> Could not find the language line "vendor_home_page"
ERROR - 2023-05-18 12:01:49 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:01:52 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:03:44 --> Could not find the language line "vendor_home_page"
ERROR - 2023-05-18 12:08:56 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:09:05 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:09:10 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:09:53 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 12:09:53 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 12:09:59 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 12:09:59 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 12:10:05 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:10:05 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:11:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-18 12:11:23 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-18 12:11:55 --> Could not find the language line "user_order_history"
ERROR - 2023-05-18 12:12:01 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:12:01 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:12:03 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-18 12:12:06 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:12:06 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:12:07 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-18 12:12:10 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:12:10 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:12:13 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-18 12:12:19 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:12:19 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:12:20 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-18 12:12:23 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:12:23 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:12:27 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-18 12:12:32 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:12:32 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:12:34 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-18 12:12:37 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:12:37 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:12:41 --> Could not find the language line "user_order_history"
ERROR - 2023-05-18 12:12:57 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:12:57 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:12:58 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-18 12:13:01 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:13:01 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:13:09 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-18 12:13:11 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:13:11 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:13:13 --> Could not find the language line "user_order_history"
ERROR - 2023-05-18 12:13:15 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:13:15 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:13:16 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-18 12:13:19 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:13:19 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:13:20 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-18 12:13:23 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:13:23 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:13:24 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-18 12:13:27 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:13:27 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:13:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-18 12:13:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-18 12:13:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-18 12:13:58 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-18 12:14:02 --> Could not find the language line "user_order_history"
ERROR - 2023-05-18 12:14:11 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:14:11 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:14:14 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:14:14 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:14:24 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:14:24 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:14:25 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-18 12:14:29 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:14:29 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:14:31 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-18 12:14:34 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:14:34 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:14:46 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-18 12:14:51 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-18 12:14:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-18 12:15:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-18 12:15:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-18 12:15:36 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:15:36 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:15:38 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-18 12:15:43 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:15:43 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:15:45 --> Could not find the language line "user_order_history"
ERROR - 2023-05-18 12:16:01 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-18 12:16:13 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:16:13 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:16:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-18 12:16:27 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-18 12:17:15 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 12:17:15 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 12:17:19 --> Could not find the language line "Mechanic"
ERROR - 2023-05-18 12:17:20 --> Could not find the language line "Mechanic"
ERROR - 2023-05-18 12:17:25 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 12:17:25 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 12:17:31 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 12:17:31 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 12:17:42 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 12:17:42 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 12:17:55 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 12:17:55 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 12:17:57 --> Could not find the language line "Mechanic"
ERROR - 2023-05-18 12:17:58 --> Could not find the language line "Mechanic"
ERROR - 2023-05-18 12:18:02 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 12:18:02 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 12:18:03 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 12:18:03 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 12:18:06 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 12:18:06 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 12:38:35 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:38:35 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:38:57 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 12:38:57 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 12:38:57 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 12:38:57 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 12:39:10 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 12:39:10 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 12:39:11 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 12:39:11 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 12:39:13 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 12:39:13 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 12:39:13 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 12:39:13 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 12:39:14 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 12:39:14 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 12:39:18 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 12:39:18 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 12:39:31 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 12:39:31 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 12:39:33 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 12:39:33 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 12:39:36 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 12:39:36 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 12:39:38 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 12:39:38 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 12:39:39 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 12:39:39 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 12:39:42 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 12:39:42 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 12:39:43 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 12:39:43 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 12:39:47 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 12:39:47 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 12:39:55 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 12:39:55 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 12:39:57 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 12:39:57 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 12:39:58 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 12:39:58 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 12:39:59 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 12:39:59 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 12:40:01 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 12:40:01 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 12:40:06 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 12:40:06 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 12:40:06 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 12:40:06 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 12:40:11 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 12:40:11 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 12:40:21 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:40:21 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:40:25 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-18 12:40:28 --> 404 Page Not Found: /index
ERROR - 2023-05-18 12:40:28 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:36:39 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-18 17:37:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-18 17:37:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-18 17:37:26 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:37:26 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:37:34 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:37:34 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:37:44 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:37:44 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:37:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-18 17:37:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-18 17:37:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-18 17:37:56 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:37:56 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:38:02 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-18 17:38:04 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:38:04 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:38:06 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:38:06 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:38:08 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-18 17:38:09 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:38:10 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:38:14 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:38:14 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:38:15 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-18 17:38:17 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:38:17 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:38:18 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-18 17:38:20 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:38:20 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:38:22 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-18 17:38:26 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:38:26 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:38:27 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-18 17:38:29 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:38:29 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:38:32 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:38:32 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:38:33 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-18 17:38:34 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:38:34 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:38:36 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:38:36 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:38:41 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:38:41 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:38:42 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-18 17:38:45 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-18 17:38:46 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-18 17:38:46 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-18 17:38:46 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-18 17:38:47 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:38:47 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:38:52 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-18 17:38:53 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:38:53 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:38:54 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-18 17:38:57 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:38:57 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:39:01 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-18 17:39:02 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:39:03 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:39:06 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-18 17:39:08 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:39:08 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:39:19 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 17:39:19 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 17:39:22 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 17:39:22 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 17:39:29 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 17:39:29 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 17:39:33 --> Could not find the language line "Mechanic"
ERROR - 2023-05-18 17:39:44 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 17:39:44 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 17:39:47 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:39:47 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:39:48 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-18 17:39:50 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:39:50 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:39:55 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 17:39:55 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 17:39:57 --> Could not find the language line "Mechanic"
ERROR - 2023-05-18 17:39:59 --> Could not find the language line "Mechanic"
ERROR - 2023-05-18 17:39:59 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\redlabel\view_product.php 70
ERROR - 2023-05-18 17:40:03 --> Could not find the language line "Mechanic"
ERROR - 2023-05-18 17:40:06 --> Could not find the language line "Mechanic"
ERROR - 2023-05-18 17:40:06 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\redlabel\view_product.php 70
ERROR - 2023-05-18 17:40:08 --> Could not find the language line "Mechanic"
ERROR - 2023-05-18 17:40:17 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 17:40:17 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 17:40:21 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:40:21 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:40:29 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-18 17:40:32 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:40:32 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:40:43 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:40:43 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:40:51 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:40:52 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:41:02 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:41:02 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:41:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-18 17:41:58 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:41:58 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:42:20 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:42:20 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:42:29 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:42:29 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:42:40 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-18 17:42:42 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:42:42 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:42:44 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-18 17:42:46 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:42:46 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:42:50 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-18 17:42:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-18 17:42:55 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:42:56 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:43:32 --> Could not find the language line "user_order_history"
ERROR - 2023-05-18 17:43:40 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:43:40 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:44:01 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:44:01 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:44:04 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:44:04 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:44:12 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:44:12 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:44:16 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:44:16 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:44:19 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:44:19 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:44:29 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 17:44:29 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 17:44:35 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 17:44:35 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 17:44:41 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-05-18 17:44:41 --> Could not find the language line "show_menu"
ERROR - 2023-05-18 17:44:41 --> Could not find the language line "hide_menu"
ERROR - 2023-05-18 17:45:00 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:45:00 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:45:04 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:45:04 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:46:15 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:46:15 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:46:20 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:46:51 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:55:25 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:55:25 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:55:25 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:55:28 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:55:28 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:55:28 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:56:19 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:56:19 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:56:19 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:56:21 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:56:21 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:56:21 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:56:22 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:56:22 --> 404 Page Not Found: /index
ERROR - 2023-05-18 17:56:22 --> 404 Page Not Found: /index
ERROR - 2023-05-18 18:02:52 --> 404 Page Not Found: /index
ERROR - 2023-05-18 18:02:52 --> 404 Page Not Found: /index
ERROR - 2023-05-18 18:02:52 --> 404 Page Not Found: /index
ERROR - 2023-05-18 18:02:56 --> 404 Page Not Found: /index
ERROR - 2023-05-18 18:02:56 --> 404 Page Not Found: /index
ERROR - 2023-05-18 18:02:56 --> 404 Page Not Found: /index
ERROR - 2023-05-18 18:03:11 --> 404 Page Not Found: /index
ERROR - 2023-05-18 18:03:11 --> 404 Page Not Found: /index
ERROR - 2023-05-18 18:04:46 --> 404 Page Not Found: /index
ERROR - 2023-05-18 18:04:46 --> 404 Page Not Found: /index
ERROR - 2023-05-18 18:05:41 --> 404 Page Not Found: /index
ERROR - 2023-05-18 18:08:32 --> 404 Page Not Found: /index
ERROR - 2023-05-18 18:08:32 --> 404 Page Not Found: /index
ERROR - 2023-05-18 18:08:32 --> 404 Page Not Found: /index
ERROR - 2023-05-18 18:12:13 --> 404 Page Not Found: /index
ERROR - 2023-05-18 18:12:13 --> 404 Page Not Found: /index
ERROR - 2023-05-18 18:13:23 --> 404 Page Not Found: /index
ERROR - 2023-05-18 18:13:23 --> 404 Page Not Found: /index
ERROR - 2023-05-18 18:13:44 --> 404 Page Not Found: /index
ERROR - 2023-05-18 18:13:44 --> 404 Page Not Found: /index
ERROR - 2023-05-18 18:13:49 --> 404 Page Not Found: /index
ERROR - 2023-05-18 18:13:49 --> 404 Page Not Found: /index
ERROR - 2023-05-18 18:15:38 --> 404 Page Not Found: /index
ERROR - 2023-05-18 18:16:04 --> 404 Page Not Found: /index
ERROR - 2023-05-18 18:16:04 --> 404 Page Not Found: /index
ERROR - 2023-05-18 18:16:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-18 18:16:23 --> Could not find the language line "user_order_history"
ERROR - 2023-05-18 18:16:42 --> 404 Page Not Found: /index
ERROR - 2023-05-18 18:16:42 --> 404 Page Not Found: /index
ERROR - 2023-05-18 18:19:30 --> 404 Page Not Found: /index
ERROR - 2023-05-18 18:19:30 --> 404 Page Not Found: /index
ERROR - 2023-05-18 18:19:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-18 18:19:55 --> 404 Page Not Found: /index
ERROR - 2023-05-18 18:19:55 --> 404 Page Not Found: /index
ERROR - 2023-05-18 18:19:56 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-18 18:19:58 --> 404 Page Not Found: /index
ERROR - 2023-05-18 18:19:58 --> 404 Page Not Found: /index
ERROR - 2023-05-18 18:20:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-18 18:20:09 --> 404 Page Not Found: /index
ERROR - 2023-05-18 18:20:09 --> 404 Page Not Found: /index
ERROR - 2023-05-18 18:20:13 --> 404 Page Not Found: /index
ERROR - 2023-05-18 18:20:13 --> 404 Page Not Found: /index
