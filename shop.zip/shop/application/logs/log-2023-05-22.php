<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-22 11:31:52 --> 404 Page Not Found: /index
ERROR - 2023-05-22 11:31:52 --> 404 Page Not Found: /index
ERROR - 2023-05-22 11:32:07 --> Could not find the language line "show_menu"
ERROR - 2023-05-22 11:32:07 --> Could not find the language line "hide_menu"
ERROR - 2023-05-22 11:33:35 --> 404 Page Not Found: /index
ERROR - 2023-05-22 11:33:35 --> 404 Page Not Found: /index
ERROR - 2023-05-22 11:33:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-22 11:33:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-22 11:33:56 --> 404 Page Not Found: /index
ERROR - 2023-05-22 11:33:56 --> 404 Page Not Found: /index
ERROR - 2023-05-22 11:35:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-22 11:35:36 --> Could not find the language line "user_order_history"
ERROR - 2023-05-22 11:35:44 --> 404 Page Not Found: /index
ERROR - 2023-05-22 11:35:44 --> 404 Page Not Found: /index
ERROR - 2023-05-22 11:35:48 --> Could not find the language line "user_order_history"
ERROR - 2023-05-22 11:36:02 --> 404 Page Not Found: /index
ERROR - 2023-05-22 11:36:02 --> 404 Page Not Found: /index
ERROR - 2023-05-22 11:36:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-22 11:36:35 --> Could not find the language line "show_menu"
ERROR - 2023-05-22 11:36:35 --> Could not find the language line "hide_menu"
ERROR - 2023-05-22 11:37:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-22 11:37:22 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-22 11:37:26 --> Could not find the language line "user_order_history"
ERROR - 2023-05-22 11:37:38 --> Could not find the language line "show_menu"
ERROR - 2023-05-22 11:37:38 --> Could not find the language line "hide_menu"
ERROR - 2023-05-22 11:37:39 --> Could not find the language line "show_menu"
ERROR - 2023-05-22 11:37:39 --> Could not find the language line "hide_menu"
ERROR - 2023-05-22 11:37:59 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-22 11:38:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-22 11:38:13 --> 404 Page Not Found: /index
ERROR - 2023-05-22 11:38:13 --> 404 Page Not Found: /index
ERROR - 2023-05-22 11:38:38 --> Could not find the language line "user_order_history"
ERROR - 2023-05-22 11:39:06 --> Could not find the language line "user_order_history"
ERROR - 2023-05-22 11:39:43 --> 404 Page Not Found: /index
ERROR - 2023-05-22 11:39:43 --> 404 Page Not Found: /index
ERROR - 2023-05-22 11:39:46 --> Could not find the language line "user_order_history"
ERROR - 2023-05-22 11:40:19 --> 404 Page Not Found: /index
ERROR - 2023-05-22 11:40:19 --> 404 Page Not Found: /index
ERROR - 2023-05-22 11:40:30 --> Could not find the language line "user_order_history"
ERROR - 2023-05-22 11:41:09 --> Could not find the language line "user_order_history"
ERROR - 2023-05-22 11:41:22 --> 404 Page Not Found: /index
ERROR - 2023-05-22 11:41:23 --> 404 Page Not Found: /index
ERROR - 2023-05-22 11:41:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-22 11:42:15 --> 404 Page Not Found: /index
ERROR - 2023-05-22 11:42:15 --> 404 Page Not Found: /index
ERROR - 2023-05-22 11:42:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-22 11:42:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-22 11:44:28 --> 404 Page Not Found: /index
ERROR - 2023-05-22 11:44:28 --> 404 Page Not Found: /index
ERROR - 2023-05-22 11:44:40 --> Could not find the language line "user_order_history"
ERROR - 2023-05-22 11:45:36 --> Could not find the language line "user_order_history"
ERROR - 2023-05-22 11:47:06 --> 404 Page Not Found: /index
ERROR - 2023-05-22 11:47:06 --> 404 Page Not Found: /index
ERROR - 2023-05-22 11:52:38 --> 404 Page Not Found: /index
ERROR - 2023-05-22 11:54:58 --> 404 Page Not Found: /index
ERROR - 2023-05-22 11:55:18 --> 404 Page Not Found: /index
ERROR - 2023-05-22 11:55:30 --> 404 Page Not Found: /index
ERROR - 2023-05-22 11:55:30 --> 404 Page Not Found: /index
ERROR - 2023-05-22 11:55:32 --> Could not find the language line "user_order_history"
ERROR - 2023-05-22 11:55:40 --> 404 Page Not Found: /index
ERROR - 2023-05-22 12:01:37 --> Could not find the language line "user_order_history"
ERROR - 2023-05-22 12:01:37 --> Could not find the language line "usr_order_price"
ERROR - 2023-05-22 12:01:37 --> Severity: Warning --> Undefined array key "price" C:\xampp\htdocs\shop\application\views\templates\greenlabel\user.php 48
ERROR - 2023-05-22 12:01:37 --> Severity: Warning --> Undefined array key "price" C:\xampp\htdocs\shop\application\views\templates\greenlabel\user.php 48
ERROR - 2023-05-22 12:01:37 --> Severity: Warning --> Undefined array key "price" C:\xampp\htdocs\shop\application\views\templates\greenlabel\user.php 48
ERROR - 2023-05-22 12:01:37 --> Severity: Warning --> Undefined array key "price" C:\xampp\htdocs\shop\application\views\templates\greenlabel\user.php 48
ERROR - 2023-05-22 12:02:49 --> Could not find the language line "user_order_history"
ERROR - 2023-05-22 12:03:01 --> 404 Page Not Found: /index
ERROR - 2023-05-22 12:03:01 --> 404 Page Not Found: /index
ERROR - 2023-05-22 12:03:10 --> 404 Page Not Found: /index
ERROR - 2023-05-22 12:03:10 --> 404 Page Not Found: /index
ERROR - 2023-05-22 12:03:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-22 12:03:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-22 12:03:31 --> 404 Page Not Found: /index
ERROR - 2023-05-22 12:03:31 --> 404 Page Not Found: /index
ERROR - 2023-05-22 12:03:47 --> 404 Page Not Found: /index
ERROR - 2023-05-22 12:03:48 --> 404 Page Not Found: /index
ERROR - 2023-05-22 12:03:50 --> Could not find the language line "user_order_history"
ERROR - 2023-05-22 12:03:53 --> 404 Page Not Found: /index
ERROR - 2023-05-22 12:03:53 --> 404 Page Not Found: /index
ERROR - 2023-05-22 12:04:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-22 12:04:13 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-22 12:04:28 --> 404 Page Not Found: /index
ERROR - 2023-05-22 12:04:28 --> 404 Page Not Found: /index
ERROR - 2023-05-22 12:04:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-22 12:04:38 --> 404 Page Not Found: /index
ERROR - 2023-05-22 12:04:38 --> 404 Page Not Found: /index
ERROR - 2023-05-22 12:04:46 --> 404 Page Not Found: /index
ERROR - 2023-05-22 12:04:46 --> 404 Page Not Found: /index
ERROR - 2023-05-22 12:04:49 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-22 12:04:58 --> 404 Page Not Found: /index
ERROR - 2023-05-22 12:04:58 --> 404 Page Not Found: /index
ERROR - 2023-05-22 12:05:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-22 12:05:09 --> 404 Page Not Found: /index
ERROR - 2023-05-22 12:05:09 --> 404 Page Not Found: /index
ERROR - 2023-05-22 12:05:16 --> 404 Page Not Found: /index
ERROR - 2023-05-22 12:05:16 --> 404 Page Not Found: /index
ERROR - 2023-05-22 12:06:38 --> 404 Page Not Found: /index
ERROR - 2023-05-22 12:06:38 --> 404 Page Not Found: /index
ERROR - 2023-05-22 12:07:16 --> 404 Page Not Found: /index
ERROR - 2023-05-22 12:07:16 --> 404 Page Not Found: /index
ERROR - 2023-05-22 12:09:44 --> 404 Page Not Found: /index
ERROR - 2023-05-22 12:09:44 --> 404 Page Not Found: /index
ERROR - 2023-05-22 12:10:52 --> Could not find the language line "show_menu"
ERROR - 2023-05-22 12:10:52 --> Could not find the language line "hide_menu"
ERROR - 2023-05-22 12:11:03 --> Could not find the language line "show_menu"
ERROR - 2023-05-22 12:11:03 --> Could not find the language line "hide_menu"
ERROR - 2023-05-22 12:11:16 --> 404 Page Not Found: /index
ERROR - 2023-05-22 12:11:16 --> 404 Page Not Found: /index
ERROR - 2023-05-22 12:11:30 --> Could not find the language line "show_menu"
ERROR - 2023-05-22 12:11:30 --> Could not find the language line "hide_menu"
ERROR - 2023-05-22 12:11:58 --> Could not find the language line "show_menu"
ERROR - 2023-05-22 12:11:58 --> Could not find the language line "hide_menu"
ERROR - 2023-05-22 12:12:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-22 12:12:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-22 12:12:29 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-22 12:12:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-22 12:13:24 --> Could not find the language line "show_menu"
ERROR - 2023-05-22 12:13:24 --> Could not find the language line "hide_menu"
ERROR - 2023-05-22 12:13:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-22 12:13:55 --> Could not find the language line "show_menu"
ERROR - 2023-05-22 12:13:55 --> Could not find the language line "hide_menu"
ERROR - 2023-05-22 12:14:03 --> Could not find the language line "show_menu"
ERROR - 2023-05-22 12:14:03 --> Could not find the language line "hide_menu"
ERROR - 2023-05-22 12:14:05 --> Could not find the language line "show_menu"
ERROR - 2023-05-22 12:14:05 --> Could not find the language line "hide_menu"
ERROR - 2023-05-22 12:14:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-22 12:14:25 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-22 12:14:34 --> Could not find the language line "show_menu"
ERROR - 2023-05-22 12:14:34 --> Could not find the language line "hide_menu"
ERROR - 2023-05-22 12:14:35 --> Could not find the language line "show_menu"
ERROR - 2023-05-22 12:14:35 --> Could not find the language line "hide_menu"
ERROR - 2023-05-22 12:14:44 --> Could not find the language line "show_menu"
ERROR - 2023-05-22 12:14:44 --> Could not find the language line "hide_menu"
ERROR - 2023-05-22 12:15:00 --> 404 Page Not Found: /index
ERROR - 2023-05-22 12:15:00 --> 404 Page Not Found: /index
ERROR - 2023-05-22 12:15:03 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-22 12:15:05 --> 404 Page Not Found: /index
ERROR - 2023-05-22 12:15:05 --> 404 Page Not Found: /index
ERROR - 2023-05-22 12:15:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-22 12:16:01 --> 404 Page Not Found: /index
ERROR - 2023-05-22 12:16:01 --> 404 Page Not Found: /index
ERROR - 2023-05-22 12:16:19 --> Could not find the language line "show_menu"
ERROR - 2023-05-22 12:16:19 --> Could not find the language line "hide_menu"
ERROR - 2023-05-22 12:16:19 --> Could not find the language line "show_menu"
ERROR - 2023-05-22 12:16:19 --> Could not find the language line "hide_menu"
ERROR - 2023-05-22 12:16:25 --> Could not find the language line "show_menu"
ERROR - 2023-05-22 12:16:25 --> Could not find the language line "hide_menu"
ERROR - 2023-05-22 12:17:23 --> 404 Page Not Found: /index
ERROR - 2023-05-22 12:17:23 --> 404 Page Not Found: /index
ERROR - 2023-05-22 12:19:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-22 12:19:41 --> 404 Page Not Found: /index
ERROR - 2023-05-22 12:19:41 --> 404 Page Not Found: /index
ERROR - 2023-05-22 12:20:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-22 12:20:48 --> 404 Page Not Found: /index
ERROR - 2023-05-22 12:20:48 --> 404 Page Not Found: /index
ERROR - 2023-05-22 12:21:06 --> 404 Page Not Found: /index
ERROR - 2023-05-22 12:21:07 --> 404 Page Not Found: /index
ERROR - 2023-05-22 12:22:00 --> 404 Page Not Found: /index
ERROR - 2023-05-22 12:22:00 --> 404 Page Not Found: /index
ERROR - 2023-05-22 17:45:40 --> 404 Page Not Found: /index
ERROR - 2023-05-22 17:45:40 --> 404 Page Not Found: /index
ERROR - 2023-05-22 17:45:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-22 17:45:58 --> 404 Page Not Found: /index
ERROR - 2023-05-22 17:45:58 --> 404 Page Not Found: /index
ERROR - 2023-05-22 17:48:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-22 17:48:02 --> 404 Page Not Found: /index
ERROR - 2023-05-22 17:48:02 --> 404 Page Not Found: /index
ERROR - 2023-05-22 17:48:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-22 17:48:07 --> 404 Page Not Found: /index
ERROR - 2023-05-22 17:48:07 --> 404 Page Not Found: /index
ERROR - 2023-05-22 17:48:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-22 17:48:24 --> 404 Page Not Found: /index
ERROR - 2023-05-22 17:48:24 --> 404 Page Not Found: /index
ERROR - 2023-05-22 17:48:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-22 17:48:33 --> 404 Page Not Found: /index
ERROR - 2023-05-22 17:48:33 --> 404 Page Not Found: /index
ERROR - 2023-05-22 17:48:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-22 17:48:44 --> Could not find the language line "user_order_history"
ERROR - 2023-05-22 17:49:08 --> 404 Page Not Found: /index
ERROR - 2023-05-22 17:50:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\controllers\Home.php 130
ERROR - 2023-05-22 17:50:14 --> 404 Page Not Found: 
ERROR - 2023-05-22 17:50:42 --> 404 Page Not Found: /index
ERROR - 2023-05-22 17:50:42 --> 404 Page Not Found: /index
ERROR - 2023-05-22 17:50:59 --> 404 Page Not Found: /index
ERROR - 2023-05-22 17:50:59 --> 404 Page Not Found: /index
ERROR - 2023-05-22 17:51:05 --> 404 Page Not Found: /index
ERROR - 2023-05-22 17:51:05 --> 404 Page Not Found: /index
ERROR - 2023-05-22 17:51:12 --> 404 Page Not Found: /index
ERROR - 2023-05-22 17:51:12 --> 404 Page Not Found: /index
ERROR - 2023-05-22 17:51:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-22 17:51:22 --> 404 Page Not Found: /index
ERROR - 2023-05-22 17:51:22 --> 404 Page Not Found: /index
ERROR - 2023-05-22 17:51:25 --> 404 Page Not Found: /index
ERROR - 2023-05-22 17:51:25 --> 404 Page Not Found: /index
ERROR - 2023-05-22 17:51:34 --> Could not find the language line "user_order_history"
ERROR - 2023-05-22 17:52:31 --> 404 Page Not Found: /index
ERROR - 2023-05-22 17:52:31 --> 404 Page Not Found: /index
ERROR - 2023-05-22 17:52:39 --> Could not find the language line "user_order_history"
ERROR - 2023-05-22 17:52:41 --> 404 Page Not Found: /index
ERROR - 2023-05-22 17:52:41 --> 404 Page Not Found: /index
ERROR - 2023-05-22 17:53:06 --> 404 Page Not Found: /index
ERROR - 2023-05-22 17:53:06 --> 404 Page Not Found: /index
ERROR - 2023-05-22 17:53:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-22 17:53:51 --> 404 Page Not Found: /index
ERROR - 2023-05-22 17:53:51 --> 404 Page Not Found: /index
ERROR - 2023-05-22 17:56:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-22 17:56:02 --> Could not find the language line "user_order_history"
ERROR - 2023-05-22 17:56:37 --> 404 Page Not Found: /index
ERROR - 2023-05-22 17:56:37 --> 404 Page Not Found: /index
ERROR - 2023-05-22 17:59:04 --> 404 Page Not Found: /index
ERROR - 2023-05-22 17:59:04 --> 404 Page Not Found: /index
ERROR - 2023-05-22 17:59:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-22 17:59:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-22 17:59:15 --> 404 Page Not Found: /index
ERROR - 2023-05-22 17:59:15 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:00:38 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:00:38 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:09:35 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:12:16 --> Could not find the language line "user_order_history"
ERROR - 2023-05-22 18:19:01 --> Could not find the language line "user_order_history"
ERROR - 2023-05-22 18:21:38 --> Could not find the language line "user_order_history"
ERROR - 2023-05-22 18:22:57 --> Could not find the language line "user_order_history"
ERROR - 2023-05-22 18:23:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-22 18:23:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-22 18:23:28 --> Could not find the language line "user_order_history"
ERROR - 2023-05-22 18:23:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-22 18:23:57 --> Could not find the language line "user_order_history"
ERROR - 2023-05-22 18:26:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\controllers\Home.php 130
ERROR - 2023-05-22 18:26:14 --> 404 Page Not Found: 
ERROR - 2023-05-22 18:26:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-22 18:26:49 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-22 18:26:51 --> Could not find the language line "user_order_history"
ERROR - 2023-05-22 18:26:54 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-22 18:27:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-22 18:27:05 --> Could not find the language line "user_order_history"
ERROR - 2023-05-22 18:27:17 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:27:17 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:27:24 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:27:24 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:27:44 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:27:44 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:27:59 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:27:59 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:28:22 --> Could not find the language line "user_order_history"
ERROR - 2023-05-22 18:28:38 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:28:38 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:28:55 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:28:55 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:29:04 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:29:04 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:29:17 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:29:17 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:31:39 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:31:39 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:31:41 --> Could not find the language line "user_order_history"
ERROR - 2023-05-22 18:32:28 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:32:28 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:32:45 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-22 18:34:03 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-22 18:34:05 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-22 18:35:46 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-22 18:37:06 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-22 18:37:32 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:37:32 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:37:38 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:37:38 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:37:48 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:37:48 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:37:52 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:37:52 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:39:41 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:39:41 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:39:58 --> Could not find the language line "user_order_history"
ERROR - 2023-05-22 18:40:11 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:40:11 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:40:40 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:40:40 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:40:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-22 18:41:05 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-22 18:41:08 --> Could not find the language line "user_order_history"
ERROR - 2023-05-22 18:41:16 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:41:16 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:42:42 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:42:42 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:43:07 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:43:07 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:43:12 --> Could not find the language line "user_order_history"
ERROR - 2023-05-22 18:43:18 --> Could not find the language line "user_order_history"
ERROR - 2023-05-22 18:43:22 --> Could not find the language line "user_order_history"
ERROR - 2023-05-22 18:43:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\controllers\Home.php 130
ERROR - 2023-05-22 18:43:30 --> 404 Page Not Found: 
ERROR - 2023-05-22 18:44:02 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:44:02 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:44:07 --> Could not find the language line "user_order_history"
ERROR - 2023-05-22 18:44:13 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:44:13 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:44:39 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:44:39 --> 404 Page Not Found: /index
ERROR - 2023-05-22 18:44:49 --> Could not find the language line "user_order_history"
ERROR - 2023-05-22 18:45:00 --> 404 Page Not Found: /index
