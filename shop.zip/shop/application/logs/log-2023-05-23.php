<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-23 06:14:16 --> 404 Page Not Found: /index
ERROR - 2023-05-23 06:14:16 --> 404 Page Not Found: /index
ERROR - 2023-05-23 06:14:36 --> Could not find the language line "show_menu"
ERROR - 2023-05-23 06:14:36 --> Could not find the language line "hide_menu"
ERROR - 2023-05-23 06:14:38 --> Could not find the language line "show_menu"
ERROR - 2023-05-23 06:14:38 --> Could not find the language line "hide_menu"
ERROR - 2023-05-23 06:15:23 --> Could not find the language line "show_menu"
ERROR - 2023-05-23 06:15:23 --> Could not find the language line "hide_menu"
ERROR - 2023-05-23 06:15:30 --> Could not find the language line "show_menu"
ERROR - 2023-05-23 06:15:30 --> Could not find the language line "hide_menu"
ERROR - 2023-05-23 06:15:30 --> Could not find the language line "show_menu"
ERROR - 2023-05-23 06:15:30 --> Could not find the language line "hide_menu"
ERROR - 2023-05-23 06:15:33 --> Could not find the language line "show_menu"
ERROR - 2023-05-23 06:15:33 --> Could not find the language line "hide_menu"
ERROR - 2023-05-23 06:17:14 --> 404 Page Not Found: /index
ERROR - 2023-05-23 06:17:14 --> 404 Page Not Found: /index
ERROR - 2023-05-23 06:17:21 --> 404 Page Not Found: /index
ERROR - 2023-05-23 06:17:21 --> 404 Page Not Found: /index
ERROR - 2023-05-23 06:17:24 --> 404 Page Not Found: /index
ERROR - 2023-05-23 06:17:24 --> 404 Page Not Found: /index
ERROR - 2023-05-23 06:19:49 --> Could not find the language line "show_menu"
ERROR - 2023-05-23 06:19:49 --> Could not find the language line "hide_menu"
ERROR - 2023-05-23 06:20:41 --> Could not find the language line "show_menu"
ERROR - 2023-05-23 06:20:41 --> Could not find the language line "hide_menu"
ERROR - 2023-05-23 06:22:21 --> Could not find the language line "show_menu"
ERROR - 2023-05-23 06:22:21 --> Could not find the language line "hide_menu"
ERROR - 2023-05-23 06:22:40 --> 404 Page Not Found: /index
ERROR - 2023-05-23 06:22:40 --> 404 Page Not Found: /index
ERROR - 2023-05-23 06:23:40 --> Could not find the language line "show_menu"
ERROR - 2023-05-23 06:23:40 --> Could not find the language line "hide_menu"
ERROR - 2023-05-23 06:23:50 --> Could not find the language line "show_menu"
ERROR - 2023-05-23 06:23:50 --> Could not find the language line "hide_menu"
ERROR - 2023-05-23 06:24:12 --> 404 Page Not Found: /index
ERROR - 2023-05-23 06:24:12 --> 404 Page Not Found: /index
ERROR - 2023-05-23 06:24:28 --> 404 Page Not Found: /index
ERROR - 2023-05-23 06:24:28 --> 404 Page Not Found: /index
ERROR - 2023-05-23 06:25:40 --> 404 Page Not Found: /index
ERROR - 2023-05-23 06:25:40 --> 404 Page Not Found: /index
ERROR - 2023-05-23 06:25:59 --> 404 Page Not Found: /index
ERROR - 2023-05-23 06:25:59 --> 404 Page Not Found: /index
ERROR - 2023-05-23 06:26:02 --> Could not find the language line "user_order_history"
ERROR - 2023-05-23 06:26:06 --> 404 Page Not Found: /index
ERROR - 2023-05-23 06:26:06 --> 404 Page Not Found: /index
ERROR - 2023-05-23 06:26:12 --> Could not find the language line "user_order_history"
ERROR - 2023-05-23 06:26:14 --> 404 Page Not Found: /index
ERROR - 2023-05-23 06:26:14 --> 404 Page Not Found: /index
ERROR - 2023-05-23 06:35:05 --> 404 Page Not Found: /index
ERROR - 2023-05-23 06:35:05 --> 404 Page Not Found: /index
ERROR - 2023-05-23 06:35:07 --> 404 Page Not Found: /index
ERROR - 2023-05-23 06:35:07 --> 404 Page Not Found: /index
ERROR - 2023-05-23 06:35:08 --> 404 Page Not Found: /index
ERROR - 2023-05-23 06:35:08 --> 404 Page Not Found: /index
ERROR - 2023-05-23 06:35:42 --> 404 Page Not Found: /index
ERROR - 2023-05-23 06:35:42 --> 404 Page Not Found: /index
ERROR - 2023-05-23 06:38:17 --> 404 Page Not Found: /index
ERROR - 2023-05-23 06:38:17 --> 404 Page Not Found: /index
ERROR - 2023-05-23 06:52:29 --> 404 Page Not Found: /index
ERROR - 2023-05-23 06:52:29 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:05:09 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:05:09 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:05:21 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:05:21 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:06:09 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:06:09 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:06:19 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:16:05 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:16:05 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:16:05 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:16:08 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:16:08 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:16:08 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:16:10 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:16:10 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:16:15 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:16:15 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:16:15 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:16:17 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:16:17 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:17:34 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:17:34 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:17:59 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:17:59 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:18:07 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:18:07 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:18:09 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:18:09 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:18:12 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:18:13 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:18:44 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:18:44 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:18:47 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:18:47 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:18:48 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:18:48 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:18:48 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:18:49 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:18:49 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:27:17 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:27:17 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:35:35 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:35:35 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:41:19 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:41:19 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:41:21 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:41:21 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:41:22 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:41:23 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:54:05 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:54:05 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:54:09 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:54:09 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:54:20 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:54:20 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:54:33 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:54:33 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:54:51 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:54:51 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:55:09 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:55:09 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:55:29 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:55:29 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:55:36 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:55:36 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:56:21 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:56:21 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:56:25 --> Could not find the language line "user_order_history"
ERROR - 2023-05-23 07:56:31 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:56:31 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:58:01 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-23 07:58:04 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:58:04 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:58:16 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:58:16 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:58:24 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:58:24 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:58:57 --> Could not find the language line "user_order_history"
ERROR - 2023-05-23 07:59:47 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:59:47 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:59:57 --> 404 Page Not Found: /index
ERROR - 2023-05-23 07:59:57 --> 404 Page Not Found: /index
ERROR - 2023-05-23 08:00:04 --> Could not find the language line "user_order_history"
ERROR - 2023-05-23 08:00:07 --> 404 Page Not Found: /index
ERROR - 2023-05-23 08:00:07 --> 404 Page Not Found: /index
ERROR - 2023-05-23 10:22:00 --> 404 Page Not Found: /index
ERROR - 2023-05-23 10:24:30 --> 404 Page Not Found: /index
ERROR - 2023-05-23 10:24:30 --> 404 Page Not Found: /index
ERROR - 2023-05-23 10:24:30 --> 404 Page Not Found: /index
ERROR - 2023-05-23 10:25:00 --> 404 Page Not Found: /index
ERROR - 2023-05-23 10:25:00 --> 404 Page Not Found: /index
ERROR - 2023-05-23 10:25:00 --> 404 Page Not Found: /index
ERROR - 2023-05-23 10:26:51 --> 404 Page Not Found: /index
ERROR - 2023-05-23 10:26:51 --> 404 Page Not Found: /index
ERROR - 2023-05-23 10:26:51 --> 404 Page Not Found: /index
ERROR - 2023-05-23 10:26:58 --> 404 Page Not Found: /index
ERROR - 2023-05-23 10:26:58 --> 404 Page Not Found: /index
ERROR - 2023-05-23 10:27:00 --> 404 Page Not Found: /index
ERROR - 2023-05-23 10:27:00 --> 404 Page Not Found: /index
ERROR - 2023-05-23 10:27:00 --> 404 Page Not Found: /index
ERROR - 2023-05-23 10:27:31 --> 404 Page Not Found: /index
