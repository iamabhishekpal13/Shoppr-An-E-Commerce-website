<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-16 17:30:25 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 17:30:33 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:30:33 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:30:33 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:37:02 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:37:02 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:37:02 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:38:57 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:38:57 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:38:57 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:39:00 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:39:00 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:39:00 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:39:10 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:39:10 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:39:10 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:39:11 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:39:11 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:39:11 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:39:12 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:39:12 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:39:12 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:40:36 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:40:36 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:40:36 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:40:49 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:40:49 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:40:49 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:40:50 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:40:50 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:40:51 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:41:02 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:41:02 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:41:02 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:41:18 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:41:18 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:41:18 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:41:53 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:41:53 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:41:53 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:43:55 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:43:55 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:43:55 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:45:20 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:45:20 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:45:20 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:45:32 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:45:32 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:45:32 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:45:41 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:45:41 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:45:41 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:46:20 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:46:20 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:46:21 --> 404 Page Not Found: /index
ERROR - 2023-05-16 17:54:29 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 17:54:35 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 17:54:38 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 17:55:16 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 17:55:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-16 17:55:29 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-16 17:55:29 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 17:55:47 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 17:55:50 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 17:55:54 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 17:55:59 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 17:56:00 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 17:56:02 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 17:56:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-16 17:56:11 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-16 17:56:11 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 17:57:37 --> Could not find the language line "show_menu"
ERROR - 2023-05-16 17:57:37 --> Could not find the language line "hide_menu"
ERROR - 2023-05-16 17:57:39 --> Could not find the language line "show_menu"
ERROR - 2023-05-16 17:57:39 --> Could not find the language line "hide_menu"
ERROR - 2023-05-16 17:57:58 --> Could not find the language line "show_menu"
ERROR - 2023-05-16 17:57:58 --> Could not find the language line "hide_menu"
ERROR - 2023-05-16 17:58:22 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 18:00:42 --> 404 Page Not Found: /index
ERROR - 2023-05-16 18:00:42 --> 404 Page Not Found: /index
ERROR - 2023-05-16 18:00:42 --> 404 Page Not Found: /index
ERROR - 2023-05-16 18:00:47 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 18:00:50 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 18:00:52 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 18:00:54 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 18:00:55 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 18:00:56 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 18:00:56 --> 404 Page Not Found: /index
ERROR - 2023-05-16 18:00:56 --> 404 Page Not Found: /index
ERROR - 2023-05-16 18:00:56 --> 404 Page Not Found: /index
ERROR - 2023-05-16 18:00:58 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 18:01:00 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 18:01:01 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 18:01:02 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\redlabel\view_product.php 70
ERROR - 2023-05-16 18:01:03 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 18:01:05 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 18:01:07 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 18:01:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-16 18:01:13 --> 404 Page Not Found: /index
ERROR - 2023-05-16 18:01:13 --> 404 Page Not Found: /index
ERROR - 2023-05-16 18:01:13 --> 404 Page Not Found: /index
ERROR - 2023-05-16 18:09:54 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 18:09:54 --> 404 Page Not Found: /index
ERROR - 2023-05-16 18:09:54 --> 404 Page Not Found: /index
ERROR - 2023-05-16 18:09:54 --> 404 Page Not Found: /index
ERROR - 2023-05-16 18:09:57 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 18:10:03 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 18:10:05 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 18:10:09 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 18:10:10 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 18:10:16 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 18:10:18 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 18:10:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-16 18:10:19 --> 404 Page Not Found: /index
ERROR - 2023-05-16 18:10:19 --> 404 Page Not Found: /index
ERROR - 2023-05-16 18:10:19 --> 404 Page Not Found: /index
ERROR - 2023-05-16 18:10:21 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 18:10:21 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-16 18:10:23 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 18:10:24 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 18:10:32 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 18:10:34 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 18:10:39 --> Could not find the language line "show_menu"
ERROR - 2023-05-16 18:10:39 --> Could not find the language line "hide_menu"
ERROR - 2023-05-16 18:10:43 --> Could not find the language line "show_menu"
ERROR - 2023-05-16 18:10:43 --> Could not find the language line "hide_menu"
ERROR - 2023-05-16 18:11:35 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-05-16 18:11:35 --> Could not find the language line "show_menu"
ERROR - 2023-05-16 18:11:35 --> Could not find the language line "hide_menu"
ERROR - 2023-05-16 18:11:41 --> Could not find the language line "show_menu"
ERROR - 2023-05-16 18:11:41 --> Could not find the language line "hide_menu"
ERROR - 2023-05-16 18:12:34 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-05-16 18:12:34 --> Could not find the language line "show_menu"
ERROR - 2023-05-16 18:12:34 --> Could not find the language line "hide_menu"
ERROR - 2023-05-16 18:12:38 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 18:12:42 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 18:13:05 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 18:14:05 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 18:14:13 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 18:14:24 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 18:14:28 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 18:14:31 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 18:14:32 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 18:14:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-16 18:14:54 --> Could not find the language line "show_menu"
ERROR - 2023-05-16 18:14:54 --> Could not find the language line "hide_menu"
ERROR - 2023-05-16 18:14:57 --> Could not find the language line "show_menu"
ERROR - 2023-05-16 18:14:57 --> Could not find the language line "hide_menu"
ERROR - 2023-05-16 18:15:01 --> Could not find the language line "show_menu"
ERROR - 2023-05-16 18:15:01 --> Could not find the language line "hide_menu"
ERROR - 2023-05-16 18:15:30 --> Could not find the language line "show_menu"
ERROR - 2023-05-16 18:15:30 --> Could not find the language line "hide_menu"
ERROR - 2023-05-16 18:15:42 --> Could not find the language line "show_menu"
ERROR - 2023-05-16 18:15:42 --> Could not find the language line "hide_menu"
ERROR - 2023-05-16 18:15:46 --> Could not find the language line "show_menu"
ERROR - 2023-05-16 18:15:46 --> Could not find the language line "hide_menu"
ERROR - 2023-05-16 18:15:50 --> Could not find the language line "show_menu"
ERROR - 2023-05-16 18:15:50 --> Could not find the language line "hide_menu"
ERROR - 2023-05-16 18:16:12 --> Could not find the language line "show_menu"
ERROR - 2023-05-16 18:16:12 --> Could not find the language line "hide_menu"
ERROR - 2023-05-16 18:16:13 --> Could not find the language line "show_menu"
ERROR - 2023-05-16 18:16:13 --> Could not find the language line "hide_menu"
ERROR - 2023-05-16 18:26:22 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it C:\xampp\htdocs\shop\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2023-05-16 18:26:22 --> Unable to connect to the database
ERROR - 2023-05-16 18:26:30 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 18:26:44 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 18:26:48 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 18:26:50 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 18:26:53 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 18:26:54 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 18:26:55 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 18:26:57 --> Could not find the language line "Mechanic"
ERROR - 2023-05-16 18:26:58 --> Could not find the language line "Mechanic"
