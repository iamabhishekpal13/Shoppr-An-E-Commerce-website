<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-03-17 17:14:13 --> Could not find the language line "show_menu"
ERROR - 2023-03-17 17:14:13 --> Could not find the language line "hide_menu"
ERROR - 2023-03-17 17:14:48 --> Could not find the language line "show_menu"
ERROR - 2023-03-17 17:14:48 --> Could not find the language line "hide_menu"
ERROR - 2023-03-17 17:14:48 --> Could not find the language line "show_menu"
ERROR - 2023-03-17 17:14:48 --> Could not find the language line "hide_menu"
