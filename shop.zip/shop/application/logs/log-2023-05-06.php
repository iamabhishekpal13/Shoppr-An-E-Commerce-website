<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-06 17:35:15 --> Could not find the language line "show_menu"
ERROR - 2023-05-06 17:35:15 --> Could not find the language line "hide_menu"
ERROR - 2023-05-06 17:35:35 --> Could not find the language line "show_menu"
ERROR - 2023-05-06 17:35:35 --> Could not find the language line "hide_menu"
ERROR - 2023-05-06 17:35:42 --> Could not find the language line "show_menu"
ERROR - 2023-05-06 17:35:42 --> Could not find the language line "hide_menu"
ERROR - 2023-05-06 17:37:18 --> Could not find the language line "show_menu"
ERROR - 2023-05-06 17:37:18 --> Could not find the language line "hide_menu"
ERROR - 2023-05-06 17:37:32 --> Could not find the language line "show_menu"
ERROR - 2023-05-06 17:37:32 --> Could not find the language line "hide_menu"
ERROR - 2023-05-06 17:37:36 --> Could not find the language line "show_menu"
ERROR - 2023-05-06 17:37:36 --> Could not find the language line "hide_menu"
ERROR - 2023-05-06 17:37:40 --> Could not find the language line "show_menu"
ERROR - 2023-05-06 17:37:40 --> Could not find the language line "hide_menu"
ERROR - 2023-05-06 17:38:08 --> Could not find the language line "show_menu"
ERROR - 2023-05-06 17:38:08 --> Could not find the language line "hide_menu"
ERROR - 2023-05-06 17:38:44 --> Could not find the language line "show_menu"
ERROR - 2023-05-06 17:38:44 --> Could not find the language line "hide_menu"
ERROR - 2023-05-06 17:38:58 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-05-06 17:38:58 --> Could not find the language line "show_menu"
ERROR - 2023-05-06 17:38:58 --> Could not find the language line "hide_menu"
ERROR - 2023-05-06 17:39:14 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\pro\application\views\templates\redlabel\view_product.php 70
ERROR - 2023-05-06 17:39:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\pro\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-06 17:40:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\pro\application\views\templates\redlabel\checkout.php 46
ERROR - 2023-05-06 17:40:51 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-06 17:40:57 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-06 17:41:08 --> Could not find the language line "show_menu"
ERROR - 2023-05-06 17:41:08 --> Could not find the language line "hide_menu"
ERROR - 2023-05-06 17:41:12 --> Could not find the language line "show_menu"
ERROR - 2023-05-06 17:41:12 --> Could not find the language line "hide_menu"
ERROR - 2023-05-06 17:41:37 --> Could not find the language line "show_menu"
ERROR - 2023-05-06 17:41:37 --> Could not find the language line "hide_menu"
ERROR - 2023-05-06 17:42:09 --> Could not find the language line "show_menu"
ERROR - 2023-05-06 17:42:09 --> Could not find the language line "hide_menu"
ERROR - 2023-05-06 17:42:11 --> Could not find the language line "show_menu"
ERROR - 2023-05-06 17:42:11 --> Could not find the language line "hide_menu"
ERROR - 2023-05-06 17:42:12 --> Could not find the language line "show_menu"
ERROR - 2023-05-06 17:42:12 --> Could not find the language line "hide_menu"
ERROR - 2023-05-06 17:42:13 --> Could not find the language line "show_menu"
ERROR - 2023-05-06 17:42:13 --> Could not find the language line "hide_menu"
ERROR - 2023-05-06 17:42:13 --> Could not find the language line "show_menu"
ERROR - 2023-05-06 17:42:13 --> Could not find the language line "hide_menu"
ERROR - 2023-05-06 17:42:14 --> Could not find the language line "show_menu"
ERROR - 2023-05-06 17:42:14 --> Could not find the language line "hide_menu"
ERROR - 2023-05-06 17:48:50 --> 404 Page Not Found: /index
ERROR - 2023-05-06 17:48:50 --> 404 Page Not Found: /index
ERROR - 2023-05-06 17:48:50 --> 404 Page Not Found: /index
ERROR - 2023-05-06 17:53:29 --> 404 Page Not Found: /index
ERROR - 2023-05-06 17:53:29 --> 404 Page Not Found: /index
ERROR - 2023-05-06 17:53:29 --> 404 Page Not Found: /index
ERROR - 2023-05-06 17:55:03 --> Severity: 8192 --> Required parameter $limit follows optional parameter $lang C:\xampp\htdocs\pro\application\modules\admin\models\Blog_model.php 34
ERROR - 2023-05-06 17:55:03 --> Severity: 8192 --> Required parameter $page follows optional parameter $lang C:\xampp\htdocs\pro\application\modules\admin\models\Blog_model.php 0
