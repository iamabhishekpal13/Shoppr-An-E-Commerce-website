<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-21 09:09:52 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:09:52 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:10:14 --> Could not find the language line "show_menu"
ERROR - 2023-05-21 09:10:14 --> Could not find the language line "hide_menu"
ERROR - 2023-05-21 09:10:17 --> Could not find the language line "show_menu"
ERROR - 2023-05-21 09:10:17 --> Could not find the language line "hide_menu"
ERROR - 2023-05-21 09:10:20 --> Could not find the language line "show_menu"
ERROR - 2023-05-21 09:10:20 --> Could not find the language line "hide_menu"
ERROR - 2023-05-21 09:10:48 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-05-21 09:10:48 --> Could not find the language line "show_menu"
ERROR - 2023-05-21 09:10:48 --> Could not find the language line "hide_menu"
ERROR - 2023-05-21 09:10:52 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:10:52 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:11:01 --> Could not find the language line "show_menu"
ERROR - 2023-05-21 09:11:01 --> Could not find the language line "hide_menu"
ERROR - 2023-05-21 09:11:11 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-05-21 09:11:12 --> Could not find the language line "show_menu"
ERROR - 2023-05-21 09:11:12 --> Could not find the language line "hide_menu"
ERROR - 2023-05-21 09:11:14 --> Could not find the language line "show_menu"
ERROR - 2023-05-21 09:11:14 --> Could not find the language line "hide_menu"
ERROR - 2023-05-21 09:11:36 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-05-21 09:11:36 --> Could not find the language line "show_menu"
ERROR - 2023-05-21 09:11:36 --> Could not find the language line "hide_menu"
ERROR - 2023-05-21 09:11:39 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:11:39 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:24:09 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:24:09 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:28:22 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:28:22 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:29:21 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:30:58 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:30:58 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:30:58 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:34:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-21 09:34:19 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:34:19 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:34:26 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:34:26 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:34:42 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:34:42 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:34:42 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:34:47 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:34:47 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:35:54 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:35:54 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:38:47 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:38:47 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:38:58 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:38:58 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:39:02 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:39:57 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:40:01 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-21 09:40:01 --> Severity: Warning --> Undefined array key "sum_" C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 142
ERROR - 2023-05-21 09:40:02 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:40:02 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:40:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-21 09:41:58 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:41:58 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:44:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-21 09:44:54 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:44:54 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:45:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-21 09:45:32 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:45:32 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:45:38 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:45:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-21 09:45:41 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:45:41 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:45:44 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:45:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-21 09:45:58 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:45:58 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:46:00 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:46:00 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:46:06 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:46:06 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:46:06 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:46:16 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:46:17 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:46:26 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:46:28 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:46:31 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:46:31 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:46:31 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:50:12 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-21 09:50:18 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:50:18 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:50:18 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:50:20 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:50:20 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:50:21 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-21 09:50:22 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:50:22 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:50:25 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:50:25 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:50:25 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:50:27 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:50:35 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:50:35 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:50:35 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:50:36 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-21 09:50:54 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:50:54 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:50:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-21 09:51:00 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:51:00 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:51:22 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:52:42 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:53:03 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:53:29 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:53:29 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:53:29 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:53:31 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:53:38 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:53:39 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:53:39 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:53:45 --> 404 Page Not Found: /index
ERROR - 2023-05-21 09:59:26 --> Severity: error --> Exception: Call to undefined function price_format() C:\xampp\htdocs\shop\application\libraries\ShoppingCart.php 82
ERROR - 2023-05-21 09:59:28 --> Severity: error --> Exception: Call to undefined function price_format() C:\xampp\htdocs\shop\application\libraries\ShoppingCart.php 82
ERROR - 2023-05-21 10:00:37 --> 404 Page Not Found: /index
ERROR - 2023-05-21 10:13:54 --> 404 Page Not Found: /index
ERROR - 2023-05-21 10:13:54 --> 404 Page Not Found: /index
ERROR - 2023-05-21 10:14:04 --> 404 Page Not Found: /index
ERROR - 2023-05-21 10:14:04 --> 404 Page Not Found: /index
ERROR - 2023-05-21 12:03:57 --> Could not find the language line "show_menu"
ERROR - 2023-05-21 12:03:57 --> Could not find the language line "hide_menu"
ERROR - 2023-05-21 12:03:57 --> Could not find the language line "show_menu"
ERROR - 2023-05-21 12:03:57 --> Could not find the language line "hide_menu"
ERROR - 2023-05-21 12:04:01 --> Could not find the language line "show_menu"
ERROR - 2023-05-21 12:04:01 --> Could not find the language line "hide_menu"
ERROR - 2023-05-21 12:04:02 --> Could not find the language line "show_menu"
ERROR - 2023-05-21 12:04:02 --> Could not find the language line "hide_menu"
ERROR - 2023-05-21 12:04:03 --> Could not find the language line "show_menu"
ERROR - 2023-05-21 12:04:03 --> Could not find the language line "hide_menu"
ERROR - 2023-05-21 12:04:13 --> Could not find the language line "show_menu"
ERROR - 2023-05-21 12:04:13 --> Could not find the language line "hide_menu"
ERROR - 2023-05-21 12:04:28 --> Could not find the language line "show_menu"
ERROR - 2023-05-21 12:04:28 --> Could not find the language line "hide_menu"
ERROR - 2023-05-21 12:04:31 --> Could not find the language line "show_menu"
ERROR - 2023-05-21 12:04:31 --> Could not find the language line "hide_menu"
ERROR - 2023-05-21 12:04:34 --> Could not find the language line "show_menu"
ERROR - 2023-05-21 12:04:34 --> Could not find the language line "hide_menu"
ERROR - 2023-05-21 12:04:38 --> 404 Page Not Found: /index
ERROR - 2023-05-21 12:04:38 --> 404 Page Not Found: /index
ERROR - 2023-05-21 12:06:22 --> Could not find the language line "show_menu"
ERROR - 2023-05-21 12:06:22 --> Could not find the language line "hide_menu"
ERROR - 2023-05-21 12:06:49 --> Could not find the language line "show_menu"
ERROR - 2023-05-21 12:06:49 --> Could not find the language line "hide_menu"
ERROR - 2023-05-21 12:07:48 --> Could not find the language line "show_menu"
ERROR - 2023-05-21 12:07:48 --> Could not find the language line "hide_menu"
ERROR - 2023-05-21 12:08:01 --> Could not find the language line "show_menu"
ERROR - 2023-05-21 12:08:01 --> Could not find the language line "hide_menu"
ERROR - 2023-05-21 12:08:16 --> Could not find the language line "show_menu"
ERROR - 2023-05-21 12:08:16 --> Could not find the language line "hide_menu"
ERROR - 2023-05-21 12:08:24 --> Could not find the language line "show_menu"
ERROR - 2023-05-21 12:08:24 --> Could not find the language line "hide_menu"
ERROR - 2023-05-21 12:08:26 --> Could not find the language line "show_menu"
ERROR - 2023-05-21 12:08:26 --> Could not find the language line "hide_menu"
ERROR - 2023-05-21 12:08:31 --> Could not find the language line "show_menu"
ERROR - 2023-05-21 12:08:31 --> Could not find the language line "hide_menu"
ERROR - 2023-05-21 12:08:34 --> Could not find the language line "show_menu"
ERROR - 2023-05-21 12:08:34 --> Could not find the language line "hide_menu"
ERROR - 2023-05-21 12:08:36 --> Could not find the language line "show_menu"
ERROR - 2023-05-21 12:08:36 --> Could not find the language line "hide_menu"
ERROR - 2023-05-21 12:08:59 --> Could not find the language line "show_menu"
ERROR - 2023-05-21 12:08:59 --> Could not find the language line "hide_menu"
ERROR - 2023-05-21 12:09:01 --> Could not find the language line "show_menu"
ERROR - 2023-05-21 12:09:01 --> Could not find the language line "hide_menu"
ERROR - 2023-05-21 12:09:57 --> Could not find the language line "show_menu"
ERROR - 2023-05-21 12:09:57 --> Could not find the language line "hide_menu"
ERROR - 2023-05-21 12:12:39 --> Could not find the language line "show_menu"
ERROR - 2023-05-21 12:12:39 --> Could not find the language line "hide_menu"
ERROR - 2023-05-21 12:12:43 --> 404 Page Not Found: /index
ERROR - 2023-05-21 12:12:43 --> 404 Page Not Found: /index
ERROR - 2023-05-21 12:13:04 --> Could not find the language line "show_menu"
ERROR - 2023-05-21 12:13:04 --> Could not find the language line "hide_menu"
ERROR - 2023-05-21 12:14:19 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-05-21 12:14:19 --> Could not find the language line "show_menu"
ERROR - 2023-05-21 12:14:19 --> Could not find the language line "hide_menu"
ERROR - 2023-05-21 12:14:22 --> 404 Page Not Found: /index
ERROR - 2023-05-21 12:14:22 --> 404 Page Not Found: /index
ERROR - 2023-05-21 12:14:26 --> Severity: error --> Exception: array_count_values(): Argument #1 ($array) must be of type array, null given C:\xampp\htdocs\shop\application\views\templates\greenlabel\view_product.php 69
ERROR - 2023-05-21 12:14:28 --> 404 Page Not Found: /index
ERROR - 2023-05-21 12:14:28 --> 404 Page Not Found: /index
ERROR - 2023-05-21 12:14:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-21 12:14:34 --> 404 Page Not Found: /index
ERROR - 2023-05-21 12:14:34 --> 404 Page Not Found: /index
ERROR - 2023-05-21 12:14:55 --> Could not find the language line "show_menu"
ERROR - 2023-05-21 12:14:55 --> Could not find the language line "hide_menu"
ERROR - 2023-05-21 12:15:04 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-05-21 12:15:05 --> Could not find the language line "show_menu"
ERROR - 2023-05-21 12:15:05 --> Could not find the language line "hide_menu"
ERROR - 2023-05-21 12:15:33 --> 404 Page Not Found: /index
ERROR - 2023-05-21 12:15:33 --> 404 Page Not Found: /index
ERROR - 2023-05-21 12:18:08 --> Could not find the language line "show_menu"
ERROR - 2023-05-21 12:18:08 --> Could not find the language line "hide_menu"
ERROR - 2023-05-21 12:18:23 --> Could not find the language line "show_menu"
ERROR - 2023-05-21 12:18:23 --> Could not find the language line "hide_menu"
ERROR - 2023-05-21 12:18:28 --> 404 Page Not Found: /index
ERROR - 2023-05-21 12:18:28 --> 404 Page Not Found: /index
ERROR - 2023-05-21 12:19:28 --> Could not find the language line "show_menu"
ERROR - 2023-05-21 12:19:28 --> Could not find the language line "hide_menu"
ERROR - 2023-05-21 12:22:27 --> Could not find the language line "show_menu"
ERROR - 2023-05-21 12:22:27 --> Could not find the language line "hide_menu"
ERROR - 2023-05-21 12:22:40 --> 404 Page Not Found: /index
ERROR - 2023-05-21 12:22:40 --> 404 Page Not Found: /index
ERROR - 2023-05-21 12:22:59 --> 404 Page Not Found: /index
ERROR - 2023-05-21 12:22:59 --> 404 Page Not Found: /index
ERROR - 2023-05-21 12:23:09 --> Could not find the language line "show_menu"
ERROR - 2023-05-21 12:23:09 --> Could not find the language line "hide_menu"
ERROR - 2023-05-21 12:25:53 --> Could not find the language line "show_menu"
ERROR - 2023-05-21 12:25:53 --> Could not find the language line "hide_menu"
ERROR - 2023-05-21 12:26:04 --> 404 Page Not Found: /index
ERROR - 2023-05-21 12:26:04 --> 404 Page Not Found: /index
ERROR - 2023-05-21 12:26:56 --> Could not find the language line "show_menu"
ERROR - 2023-05-21 12:26:56 --> Could not find the language line "hide_menu"
ERROR - 2023-05-21 12:28:38 --> Could not find the language line "show_menu"
ERROR - 2023-05-21 12:28:38 --> Could not find the language line "hide_menu"
ERROR - 2023-05-21 12:28:47 --> 404 Page Not Found: /index
ERROR - 2023-05-21 12:28:47 --> 404 Page Not Found: /index
ERROR - 2023-05-21 12:29:21 --> 404 Page Not Found: /index
ERROR - 2023-05-21 12:29:21 --> 404 Page Not Found: /index
ERROR - 2023-05-21 12:30:49 --> Could not find the language line "show_menu"
ERROR - 2023-05-21 12:30:49 --> Could not find the language line "hide_menu"
ERROR - 2023-05-21 12:32:35 --> Could not find the language line "show_menu"
ERROR - 2023-05-21 12:32:35 --> Could not find the language line "hide_menu"
ERROR - 2023-05-21 12:32:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-21 12:33:21 --> 404 Page Not Found: /index
ERROR - 2023-05-21 12:33:21 --> 404 Page Not Found: /index
ERROR - 2023-05-21 12:33:30 --> 404 Page Not Found: /index
ERROR - 2023-05-21 12:33:30 --> 404 Page Not Found: /index
ERROR - 2023-05-21 12:33:39 --> 404 Page Not Found: /index
ERROR - 2023-05-21 12:33:39 --> 404 Page Not Found: /index
ERROR - 2023-05-21 12:33:41 --> 404 Page Not Found: /index
ERROR - 2023-05-21 12:33:41 --> 404 Page Not Found: /index
ERROR - 2023-05-21 12:33:48 --> 404 Page Not Found: /index
ERROR - 2023-05-21 12:33:48 --> 404 Page Not Found: /index
ERROR - 2023-05-21 12:33:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-21 12:33:51 --> 404 Page Not Found: /index
ERROR - 2023-05-21 12:33:51 --> 404 Page Not Found: /index
