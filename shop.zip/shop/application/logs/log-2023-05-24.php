<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-05-24 17:50:49 --> 404 Page Not Found: /index
ERROR - 2023-05-24 17:50:49 --> 404 Page Not Found: /index
ERROR - 2023-05-24 17:51:00 --> 404 Page Not Found: /index
ERROR - 2023-05-24 17:51:00 --> 404 Page Not Found: /index
ERROR - 2023-05-24 17:52:03 --> 404 Page Not Found: /index
ERROR - 2023-05-24 17:52:03 --> 404 Page Not Found: /index
ERROR - 2023-05-24 17:52:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-24 17:52:37 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-24 17:52:53 --> Could not find the language line "user_order_history"
ERROR - 2023-05-24 17:52:59 --> 404 Page Not Found: /index
ERROR - 2023-05-24 17:52:59 --> 404 Page Not Found: /index
ERROR - 2023-05-24 17:53:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\shop\application\views\templates\greenlabel\checkout.php 43
ERROR - 2023-05-24 17:53:19 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2023-05-24 17:53:21 --> Could not find the language line "user_order_history"
ERROR - 2023-05-24 17:53:45 --> Could not find the language line "show_menu"
ERROR - 2023-05-24 17:53:45 --> Could not find the language line "hide_menu"
ERROR - 2023-05-24 17:53:47 --> Could not find the language line "show_menu"
ERROR - 2023-05-24 17:53:47 --> Could not find the language line "hide_menu"
ERROR - 2023-05-24 17:54:20 --> Could not find the language line "user_order_history"
ERROR - 2023-05-24 17:54:31 --> Could not find the language line "show_menu"
ERROR - 2023-05-24 17:54:31 --> Could not find the language line "hide_menu"
