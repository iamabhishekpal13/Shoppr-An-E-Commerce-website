<?php 
$lang['required'] = 'Champs réquis';
