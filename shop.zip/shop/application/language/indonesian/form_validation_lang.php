<?php

$lang['required'] = 'Bidang dibutuhkan';