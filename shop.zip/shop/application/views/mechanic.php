<!doctype html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title> Shopy</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css" integrity="sha512-YWzhKL2whUzgiheMoBFwW8CKV4qpHQAEuvilg9FAn5VJUDwKZZxkJNuGM4XkWuk94WCrrwslk8yWNGmY1EduTA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="<?= base_url('assets/css/mechanic.css')?>">
</head>
<body>
   
    <section id="mechanic-header" style="background-image:url(<?= base_url('attachments/mechanicimg/mechanic3.jpg')?>)">
        <h2>#Repair Here</h2>
        <P>to repair your product, please contact with our mechanic!</P>
    </section>
    <section id="mechanic-middle">
        <h2>Contact with your mechanic now, <span style="color: black;">Free services!</span></h2>
        <h3> ## make your damage things good and attractive ##</h3>
    </section>
    <section id="feature" class="section-p1">
        <div class="fe-box" id="fe-box1">
            <img src="<?= base_url('attachments/mechanicimg/ac-mechanic.jpg')?>" alt="" height="80px" width="80px">
            <h6> AC/Heater mechanic</h6>
        </div>
        <div class="fe-box" id="fe-box2">
            <img src="<?= base_url('attachments/mechanicimg/tv-mechanic.jpg')?>" alt="" height="80px" width="80px">
            <h6>TV/Speaker mechanic</h6>
        </div>
        <div class="fe-box" id="fe-box3">
            <img src="<?= base_url('attachments/mechanicimg/computer-mechanic.jpg')?>" alt="" height="90px" width="70px">
            <h6>Computer mechanic</h6>
        </div>
        <div class="fe-box" id="fe-box4">
            <img src="<?= base_url('attachments/mechanicimg/fan-mechanic.jpg')?>" alt="" height="90px" width="90px">
            <h6> Fan/Bulb mechanic</h6>
        </div>
        <div class="fe-box" id="fe-box5">
            <img src="<?= base_url('attachments/mechanicimg/phone-mechanic.jpg')?>" alt="" height="80px" width="80px">
            <h6>Phone/Watch mechanic </h6>
        </div>
        <div class="fe-box" id="fe-box6">
            <img src="<?= base_url('attachments/mechanicimg/other-mechanic.jpg')?>" alt="" height="80px" width="80px">
            <h6>Other electronics mechanic</h6>
        </div>
    </section>
    <section>
        <div style="text-align: center;">
            <p style="color:rgb(164, 41, 41);font-size:50px;">
                <strong>Toll Free:1888000</strong>
            </P>
        </div>

    </section>

    <section id= "newsletter" class="section-p1 section-m1">
        <div class="newstext">
            <h4> Sing up for Newsletters</h4>
            <p> Get E-mail updates about our letest shop and <span> special offers.</span></p>
        </div>
        <div class="form">
            <input type="text" placeholder="Enter your email address">
            <button>Sign Up</button>
        </div>
    </section>
    <footer class="section-p1">
        <div class="col">
           <!-- <img src="logo.jpg" alt="logo" height="50px" width="60px" class="logo">-->
            <h4>Contact</h4>
            <p><strong>Address:</strong>  India,West Bengal, kolkata, College Street, 700001</p>
            <p><strong>Phone:</strong> (+91) 8768078228 /(+91) 9475189911</p>
            <p><strong>Hours:</strong>  10:00 - 18:00, Mon - Sat</p>
            <div class="follow">
                <h4> Follow us </h4>
                <div class="icon">
                    <i class="fab fa-facebook-f"></i>
                    <i class="fab fa-twitter"></i>
                    <i class="fab fa-instagram"></i>
                    <i class="fab fa-linkedin"></i>
                    <i class="fab fa-youtube"></i>
                </div>
            </div>
        </div>
        <div class="col">
            <h4>About</h4>
            <a href="#"> About Us</a>
            <a href="#">Delivery Information</a>
            <a href="#">Privacy Policy</a>
            <a href="#">Terms & Conditions</a>
            <a href="#">Contact Us</a>
        </div>
        <div class="col">
            <h4>My Account</h4>
            <a href="#"> Sign In</a>
            <a href="#">View Cart</a>
            <a href="#">My wishlist</a>
            <a href="#">Track My Order</a>
            <a href="#">Help!</a>
        </div>
        <div class="col install">
            <!-- <h4>Install App</h4>
            <p>From App Store or Google Play</p> -->
            <!-- <div class="row">
                <img src="appstore.jpg" alt="app store logo" height="40px" width="150px">
                <img src="googleplay.jpg" alt="google play logo" height="40px" width="150px">
            </div>
            <p><i><b>Secured Payment Getway</b></i></p>
            <img src="payment1.jpg" alt="payment" height="120px" width="250px" style="border-radius: 5px;"> -->
        </div>
        <div class="copyright">
            <p> @ 2023, Final year project work - Ecommerce website </p>
        </div>
    </footer>
    

      <!-- <script src="project.js"></script> -->

</body>
</html>