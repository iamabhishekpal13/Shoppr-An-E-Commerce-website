<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Mechanic extends MY_Controller
{

    private $num_rows = 20;

    public function __construct()
    {
        parent::__construct();
       
        $this->load->helper(array('pagination'));
        
    }

    
    public function index(){
        $this->load->view('mechanic');
    }

}
